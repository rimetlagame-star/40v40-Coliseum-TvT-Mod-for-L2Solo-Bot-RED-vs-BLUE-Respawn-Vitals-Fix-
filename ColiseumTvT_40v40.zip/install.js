const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const modDir = __dirname;
const filesDir = path.join(modDir, 'files');

function detectL2SoloRoot(startDir) {
    let current = path.resolve(startDir);
    for (let i = 0; i < 5; i++) {
        if (fs.existsSync(path.join(current, 'src', 'GameServer'))) {
            return current;
        }
        const parent = path.dirname(current);
        if (parent === current) break;
        current = parent;
    }
    return null;
}

const explicitArg = process.argv[2] ? path.resolve(process.argv[2]) : null;
const targetRoot = explicitArg || detectL2SoloRoot(modDir) || detectL2SoloRoot(process.cwd());

if (!targetRoot || !fs.existsSync(path.join(targetRoot, 'src', 'GameServer'))) {
    console.error('[ERRO] Nao foi possivel localizar a pasta raiz do L2Solo (contendo src/GameServer).');
    console.error('Cole os arquivos do mod dentro da pasta raiz do seu L2Solo e execute novamente,');
    console.error('ou passe o caminho: node install.js "C:\\caminho\\do\\L2Solo"');
    process.exit(1);
}

const backupDir = path.join(modDir, 'backup_tvt_' + new Date().toISOString().replace(/[:.]/g, '-'));

function backupFile(rel) {
    const src = path.join(targetRoot, rel);
    if (!fs.existsSync(src)) return;
    const dst = path.join(backupDir, rel);
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(src, dst);
}

function injectOnce(filePath, marker, anchor, replacement) {
    let content = fs.readFileSync(filePath, 'utf8');
    if (content.includes(marker)) return { changed: false, reason: 'already_installed' };
    const eol = content.includes('\r\n') ? '\r\n' : '\n';
    const normContent = content.replace(/\r\n/g, '\n');
    const normAnchor = anchor.replace(/\r\n/g, '\n');
    if (!normContent.includes(normAnchor)) return { changed: false, reason: 'anchor_not_found' };
    const normReplacement = replacement.replace(/\r\n/g, '\n');
    const updated = normContent.replace(normAnchor, normReplacement).replace(/\n/g, eol);
    fs.writeFileSync(filePath, updated, 'utf8');
    return { changed: true, reason: 'injected' };
}

console.log('=== Instalando Coliseum TvT 40v40 ===');
console.log('Projeto L2Solo detectado em:', targetRoot);

const newModules = [
    'src/GameServer/World/ColiseumTvtService.js',
    'src/GameServer/World/Generics/NpcBypasses/ColiseumTvt.js'
];

for (const rel of newModules) {
    const src = path.join(filesDir, rel);
    if (!fs.existsSync(src)) continue;
    backupFile(rel);
    const dst = path.join(targetRoot, rel);
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(src, dst);
    execFileSync(process.execPath, ['--check', dst], { stdio: 'inherit' });
    console.log('[OK] Modulo instalado:', rel);
}

const patches = [
    {
        rel: 'src/GameServer/Network/Request/Speak.js',
        marker: 'NpcBypasses/ColiseumTvt',
        anchor: '    return false;\n}',
        replacement: [
            "    const tvtMatch = /^\\.tvt(?:\\s+(.*))?$/i.exec(String(data.text || '').trim());",
            '    if (tvtMatch) {',
            "        const ColiseumTvtBypass = invoke('GameServer/World/Generics/NpcBypasses/ColiseumTvt');",
            "        const extraArgs = String(tvtMatch[1] || '').trim().split(/\\s+/).filter(Boolean);",
            "        ColiseumTvtBypass(session, ['coliseum-tvt', ...extraArgs]);",
            '        return true;',
            '    }',
            '    return false;',
            '}'
        ].join('\n')
    },
    {
        rel: 'src/GameServer/Actor/Generics/Die.js',
        marker: 'isTvTParticipant?.(actor)',
        anchor: '            festival: context.festival === true,',
        replacement: [
            '            festival: context.festival === true,',
            "            event: context.event === true || Boolean(invoke('GameServer/World/ColiseumTvtService')?.isTvTParticipant?.(actor)),"
        ].join('\n')
    },
    {
        rel: 'src/GameServer/Actor/Generics/Die.js',
        marker: 'death.coliseum_tvt',
        anchor: '    if (arenaDeath) return;',
        replacement: [
            '    if (arenaDeath) return;',
            "    const ColiseumTvtService = invoke('GameServer/World/ColiseumTvtService');",
            "    if (ColiseumTvtService?.isTvTParticipant?.(actor)) {",
            "        killEffect('death.coliseum_tvt', () => {",
            "            ColiseumTvtService.recordKill?.(actor, killer);",
            "            const isBot = Boolean(victimSession?.accountId?.startsWith?.('bot_'));",
            "            if (!isBot) {",
            "                setTimeout(() => {",
            "                    const activeTvt = invoke('GameServer/World/ColiseumTvtService');",
            "                    if (activeTvt?.isTvTParticipant?.(actor)) {",
            "                        const coord = activeTvt.getRespawnCoord?.(actor);",
            "                        if (coord) {",
            "                            invoke(path.actor).revive?.(victimSession, actor, { delayMs: 0 });",
            "                            activeTvt.handleActorRespawn?.(victimSession, actor);",
            "                        }",
            "                    }",
            "                }, 1500);",
            "            }",
            "        });",
            "        if (!victimSession?.accountId?.startsWith?.('bot_')) return;",
            "    }"
        ].join('\n')
    },
    {
        rel: 'src/GameServer/Progression/DeathExperience.js',
        marker: 'coliseum_tvt',
        anchor: "    if (context.arena || context.event || context.duel) return context.arena ? 'arena' : context.event ? 'event' : 'duel';",
        replacement: [
            "    if (context.arena || context.event || context.duel) return context.arena ? 'arena' : context.event ? 'event' : 'duel';",
            '    try {',
            "        const tvtSvc = invoke('GameServer/World/ColiseumTvtService');",
            "        if (tvtSvc?.isTvTParticipant?.(actor)) return 'coliseum_tvt';",
            '    } catch (_) {}'
        ].join('\n')
    },
    {
        rel: 'src/GameServer/Actor/Generics/MoveTo.js',
        marker: 'tvtActiveMatch',
        anchor: '    if (!previewOnly && actor.isBlocked()) {\n        invoke(path.actor).queueRequest(session, actor, \'move\', coords);\n        return;\n    }',
        replacement: [
            '    if (!previewOnly && actor.isBlocked()) {',
            "        invoke(path.actor).queueRequest(session, actor, 'move', coords);",
            '        return;',
            '    }',
            "    const tvtSvc = invoke('GameServer/World/ColiseumTvtService');",
            "    const tvtActiveMatch = tvtSvc?.getActiveMatch?.();",
            "    if (tvtActiveMatch && (session?.tvtMatchId === tvtActiveMatch.id || tvtSvc?.isTvTParticipant?.(actor))) {",
            "        if (coords?.to && typeof tvtSvc.clampToArena === 'function') {",
            "            const clampedTo = tvtSvc.clampToArena(coords.to.locX, coords.to.locY, coords.to.locZ);",
            "            coords = {",
            "                ...coords,",
            "                to: {",
            "                    ...coords.to,",
            "                    locX: clampedTo.locX,",
            "                    locY: clampedTo.locY,",
            "                    locZ: clampedTo.locZ",
            "                }",
            "            };",
            "        }",
            "        if (coords?.from && typeof tvtSvc.isInsideArena === 'function' && typeof tvtSvc.clampToArena === 'function') {",
            "            if (!tvtSvc.isInsideArena(coords.from.locX, coords.from.locY, coords.from.locZ)) {",
            "                const clampedFrom = tvtSvc.clampToArena(coords.from.locX, coords.from.locY, coords.from.locZ);",
            "                coords = {",
            "                    ...coords,",
            "                    from: {",
            "                        ...coords.from,",
            "                        locX: clampedFrom.locX,",
            "                        locY: clampedFrom.locY,",
            "                        locZ: clampedFrom.locZ",
            "                    }",
            "                };",
            "            }",
            "        }",
            "    }"
        ].join('\n')
    },
    {
        rel: 'src/GameServer/Actor/Generics/AttackExec.js',
        marker: 'tvtAtColiseum',
        anchor: '                if (data.ctrl || user.fetchPvpFlag?.() > 0 || user.fetchKarma?.() > 0) {',
        replacement: [
            "                const tvtAtColiseum = invoke('GameServer/World/ColiseumTvtService')?.areEnemies?.(actor, user) === true;",
            '                if (data.ctrl || tvtAtColiseum || user.fetchPvpFlag?.() > 0 || user.fetchKarma?.() > 0) {'
        ].join('\n')
    },
    {
        rel: 'src/GameServer/Actor/Generics/SkillExec.js',
        marker: 'areEnemies?.(actor, user)',
        anchor: "                else if (data.ctrl || user.fetchPvpFlag?.() > 0 || user.fetchKarma?.() > 0) {",
        replacement: [
            "                else if (data.ctrl || invoke('GameServer/World/ColiseumTvtService')?.areEnemies?.(actor, user) === true || user.fetchPvpFlag?.() > 0 || user.fetchKarma?.() > 0) {"
        ].join('\n')
    },
    {
        rel: 'src/GameServer/World/ArenaCombatRules.js',
        marker: 'tvt?.areEnemies?.(attacker, victim)',
        anchor: '    const duel = service().duelForActor?.(attacker) || service().duelForActor?.(victim);',
        replacement: [
            "    const tvt = invoke('GameServer/World/ColiseumTvtService');",
            "    if (tvt?.areEnemies?.(attacker, victim)) return true;",
            '    const duel = service().duelForActor?.(attacker) || service().duelForActor?.(victim);'
        ].join('\n')
    },
    {
        rel: 'src/GameServer/World/ArenaCombatRules.js',
        marker: 'tvt?.isTvTCombatPair?.(attacker, victim)',
        anchor: '    const duel = service().duelForActor?.(attacker) || service().duelForActor?.(victim);\\n    if (!duel) return false;',
        replacement: [
            "    const tvt = invoke('GameServer/World/ColiseumTvtService');",
            "    if (tvt?.isTvTCombatPair?.(attacker, victim)) return true;",
            '    const duel = service().duelForActor?.(attacker) || service().duelForActor?.(victim);',
            '    if (!duel) return false;'
        ].join('\n')
    },
    {
        rel: 'src/GameServer/Bot/Population/PopulationService.js',
        marker: 'session.tvtLocked || session.tvtMatchId',
        anchor: '                if (session.clanAllianceQuest || session.partyCompanion === true || session.followPlayerSession) return false;',
        replacement: [
            '                if (session.clanAllianceQuest || session.partyCompanion === true || session.followPlayerSession) return false;',
            '                if (session.tvtLocked || session.tvtMatchId) return false;'
        ].join('\n')
    },
    {
        rel: 'src/GameServer/Bot/BotAI.js',
        marker: 'TvtService.findEnemyTarget(session, bot, 6000)',
        anchor: '        const state = States[session.plan];',
        replacement: [
            '        if (session.tvtMatchId) {',
            '            const TvtService = invoke(\'GameServer/World/ColiseumTvtService\');',
            '            if (typeof bot.setKarma === \'function\' && Number(bot.fetchKarma?.() || 0) !== 0) {',
            '                bot.setKarma(0);',
            '            }',
            '            if (typeof bot.setPvpFlag === \'function\' && Number(bot.fetchPvpFlag?.() || 0) !== 1) {',
            '                bot.setPvpFlag(1);',
            '            }',
            '            const tvtEnemy = TvtService.findEnemyTarget(session, bot, 6000);',
            '            const GenericsActor = invoke(path.actor);',
            '            if (tvtEnemy) {',
            '                const enemyId = Number(tvtEnemy.fetchId?.() || tvtEnemy.id || 0) || undefined;',
            '                session.currentTargetId = enemyId;',
            '                if (typeof bot.setTarget === \'function\' && enemyId) {',
            '                    try { bot.setTarget(enemyId); } catch (_) {}',
            '                }',
            '                const combatEngaged = this.executePvPCombat(session, bot, tvtEnemy, Generics, { pvp: true });',
            '                const bx = Number(bot.fetchLocX?.() || 0);',
            '                const by = Number(bot.fetchLocY?.() || 0);',
            '                const bz = Number(bot.fetchLocZ?.() || TvtService.ARENA_CENTER.locZ);',
            '                const tx = Number(tvtEnemy.fetchLocX?.() || bx);',
            '                const ty = Number(tvtEnemy.fetchLocY?.() || by);',
            '                const tz = Number(tvtEnemy.fetchLocZ?.() || bz);',
            '                const dx = tx - bx;',
            '                const dy = ty - by;',
            '                const distSq = (dx * dx) + (dy * dy);',
            '                const isMoving = Boolean(bot.state?.isMoving?.() || bot.moving || session.pendingPathRequest);',
            '                if ((!combatEngaged || distSq > 220 * 220) && !isMoving && typeof GenericsActor?.moveTo === \'function\') {',
            '                    const clampedDest = typeof TvtService.clampToArena === \'function\'',
            '                        ? TvtService.clampToArena(tx, ty, tz)',
            '                        : { locX: tx, locY: ty, locZ: tz };',
            '                    GenericsActor.moveTo(session, bot, {',
            '                        from: { locX: bx, locY: by, locZ: bz },',
            '                        to: { locX: clampedDest.locX, locY: clampedDest.locY, locZ: clampedDest.locZ },',
            '                        targetActor: tvtEnemy,',
            '                        forceRepath: true',
            '                    });',
            '                }',
            '            } else {',
            '                session.currentTargetId = undefined;',
            '                const center = TvtService.ARENA_CENTER;',
            '                const isMoving = Boolean(bot.state?.isMoving?.() || bot.moving || session.pendingPathRequest);',
            '                if (!isMoving && typeof GenericsActor?.moveTo === \'function\') {',
            '                    GenericsActor.moveTo(session, bot, {',
            '                        from: { locX: Number(bot.fetchLocX?.() || center.locX), locY: Number(bot.fetchLocY?.() || center.locY), locZ: Number(bot.fetchLocZ?.() || center.locZ) },',
            '                        to: { locX: center.locX, locY: center.locY, locZ: center.locZ },',
            '                        forceRepath: true',
            '                    });',
            '                }',
            '            }',
            '            return;',
            '        }',
            '        const state = States[session.plan];'
        ].join('\n')
    },
    {
        rel: 'src/GameServer/Bot/BotAI.js',
        marker: 'TvtService.recordKill(bot, killer)',
        anchor: '                session.deathTimerStart = Date.now();',
        replacement: [
            '                session.deathTimerStart = Date.now();',
            "                if (session.tvtMatchId) {",
            "                    const TvtService = invoke('GameServer/World/ColiseumTvtService');",
            "                    const killer = bot.fetchLastAttacker?.() || bot.lastAttacker || null;",
            "                    TvtService.recordKill(bot, killer);",
            "                }"
        ].join('\n')
    },
    {
        rel: 'src/GameServer/Bot/BotAI.js',
        marker: 'tvtRespawnSvc',
        anchor: '                Generics.teleportTo(session, bot, spawnTarget);',
        replacement: [
            "                const tvtRespawnSvc = session.tvtMatchId ? invoke('GameServer/World/ColiseumTvtService') : null;",
            "                if (tvtRespawnSvc) {",
            "                    const tvtCoord = tvtRespawnSvc.getRespawnCoord?.(bot);",
            "                    if (tvtCoord) {",
            "                        spawnTarget = tvtCoord;",
            "                    }",
            "                }",
            "                Generics.teleportTo(session, bot, spawnTarget);",
            "                if (tvtRespawnSvc?.isTvTParticipant?.(bot)) {",
            "                    tvtRespawnSvc.handleActorRespawn?.(session, bot);",
            '                    if (typeof bot.fetchMaxHp === \'function\' && typeof bot.setHp === \'function\') {',
            '                        bot.setHp(Number(bot.fetchMaxHp() || 0));',
            '                    }',
            '                    if (typeof bot.fetchMaxMp === \'function\' && typeof bot.setMp === \'function\') {',
            '                        bot.setMp(Number(bot.fetchMaxMp() || 0));',
            '                    }',
            '                    if (typeof bot.fetchMaxCp === \'function\' && typeof bot.setCp === \'function\') {',
            '                        bot.setCp(Number(bot.fetchMaxCp() || 0));',
            '                    }',
            '                    bot.fillupVitals?.();',
            '                    bot.statusUpdateVitals?.(bot);',
            "                }"
        ].join('\n')
    },
    {
        rel: 'src/GameServer/Bot/BotAI.js',
        marker: 'const TvtService = invoke(\'GameServer/World/ColiseumTvtService\');',
        anchor: '        const state = States[session.plan];',
        replacement: [
            "        if (session.tvtMatchId) {",
            "                    const TvtService = invoke('GameServer/World/ColiseumTvtService');",
            "                    const killer = bot.fetchLastAttacker?.() || bot.lastAttacker || null;",
            "                    TvtService.recordKill(bot, killer);",
            "                }",
            "                if (session.hotBackgroundPartyId) {",
            "                    invoke('GameServer/Bot/Population/HotPartyLifecycle')",
            "                        .failRaidOnDeath(session, session.deathTimerStart)",
            "                        .catch((error) => utils.infoWarn('RaidBoss', 'Caí de novo. Vou esperar uma ressurreição segura ou voltar da cidade se precisar.',",
            "                            session.hotBackgroundPartyId, error?.message || error));",
            "                }",
            "                invoke('GameServer/Bot/AI/BotClanChat').onDeath(session, `hot:${session.deathTimerStart}`, session.deathTimerStart);",
            "                if (wasCompanion) {",
            "                    const deathReaction = PartyRevivalService.noteCompanionDeath(",
            "                        session.followPlayerSession,",
            "                        session,",
            "                        session.deathTimerStart",
            "                    );",
            "                    invoke('GameServer/Bot/AI/BotPartyChat').announce(session, {",
            "                        priority: 'critical',",
            "                        key: `party-death:${bot.fetchId()}`,",
            "                        templates: deathReaction.warning",
            "                            ? [",
            "                                `${bot.fetchName()} caiu — esperando ressurreição.`",
            "                            ]",
            "                            : [",
            "                                `Caído no acampamento. Esperando ressurreição.`,",
            "                                `Down at the camp. Waiting for a resurrection.`",
            "                            ]",
            "                    });",
            "                } else {",
            "                    this.say(session, Speech.line('combat.death'), { ambient: true, key: 'death' });",
            "                }",
            "                if (wasCompanion && session.followPlayerSession?.actor?.isDead?.()) {",
            "                    const BotSocialMemory = invoke('GameServer/Bot/AI/BotSocialMemory');",
            "                    BotSocialMemory.recordEvent(session.followPlayerSession, session, 'party_wiped', 'bot_and_leader_dead');",
            "                }",
            "            }",
            "",
            "            const ritualRescuePending = session.clanAllianceQuest",
            "                && invoke('GameServer/Clan/ClanAllianceService').awaitingRitualResurrection(session);",
            "            const rescueLeader = wasCompanion ? session.followPlayerSession",
            "                : session.hotBackgroundPartyId ? invoke('GameServer/Bot/AI/HotBackgroundParty').partyLeader(session) : null;",
            "            const hotParty = session.hotBackgroundPartyId",
            "                ? invoke('GameServer/Bot/Population/BackgroundPartyState').find(session.hotBackgroundPartyId)",
            "                : null;",
            "            const failedBotClanRaid = hotParty?.stats?.raidEncounter?.status === 'failed';",
            "            const partyRescuePending = !failedBotClanRaid && (ritualRescuePending",
            "                || rescueLeader && !PartyRevivalService.shouldTownRespawn(rescueLeader, session));",
            "            // Companions wait for the party's resurrection attempt.  The",
            "            // normal town restart remains the escape hatch for a wipe, an",
            "            // unsupported solo leader, or an unanswered corpse.",
            "            if (!partyRescuePending && Date.now() - session.deathTimerStart > 12000) {",
            "                const deathStartedAt = session.deathTimerStart;",
            "                // TeleportTo rejects actors that are still marked dead, so bot",
            "                // respawns must complete before applying the new town location.",
            "                const hallRuntime = invoke('GameServer/ClanHall/Runtime');",
            "                const recoveryHall = invoke('GameServer/ClanHall/BotVisit').restartHall(session, bot);",
            "                Generics.revive(session, bot, { delayMs: 0,",
            "                    restoreExpPercent: recoveryHall ? hallRuntime.expRestore(bot) : null,",
            "                    recoveryReason: recoveryHall ? 'restart_to_clan_hall' : 'restart_to_town' });",
            "                session.clanHallVisit = null;",
            "                session.deathTimerStart = undefined;",
            "                session.currentTargetId = undefined;",
            "                session.incomingThreatId = undefined;",
            "                session.incomingThreatAt = undefined;",
            "                ",
            "                let spawnTarget;",
            "                if (wasCompanion) {",
            "                    invoke('GameServer/Bot/AI/BotPartyChat').announce(session, {",
            "                        priority: 'critical',",
            "                        key: `party-respawn-timeout:${bot.fetchId()}:${deathStartedAt}`,",
            "                        templates: [",
            "                            session.clanAllianceQuest",
            "                                ? `Não veio ress. Voltando pela cidade para continuar minha missão.`",
            "                                : `Não veio ress. Voltando pela cidade, pegando buffs se precisar e retornando.`",
            "                        ]",
            "                    });",
            "                    // Keep the party relationship authoritative through the",
            "                    // town restart. Population policy must also keep this",
            "                    // visible recovery hot until the bot is back.",
            "                    session.populationHotAt = Date.now();",
            "                    session.noTargetTicks = 0;",
            "                    spawnTarget = this.beginPartyTownRecovery(session, bot);",
            "                } else if (!session.tvtMatchId && bot.fetchKarma() > 0) {",
            "                    session.plan = session.pkProfile ? 'pk_hunting' : 'hunting';",
            "                    invoke('GameServer/Bot/AI/SpotService').leaveSpot(session);",
            "                    session.noTargetTicks = 0;",
            "                    spawnTarget = this.getDeathRespawnTarget(session, bot);",
            "                } else if (session.plan === 'merchant' || (bot.fetchPrivateStore && bot.fetchPrivateStore())) {",
            "                    session.plan = 'merchant';",
            "                    bot.state.setSeated(true);",
            "                    spawnTarget = {",
            "                        locX: session.initialSpawnCoord.locX,",
            "                        locY: session.initialSpawnCoord.locY,",
            "                        locZ: session.initialSpawnCoord.locZ",
            "                    };",
            "                } else {",
            "                    session.plan = 'hunting'; // Reset plan",
            "                    // A hot party member keeps the spot it hunts on: the party tick brings it back from town.",
            "                    if (!session.hotBackgroundPartyId) invoke('GameServer/Bot/AI/SpotService').leaveSpot(session);",
            "                    session.noTargetTicks = 0;",
            "                    spawnTarget = recoveryHall?.spawn || this.getDeathRespawnTarget(session, bot, false);",
            "                }",
            "                ",
            "                const tvtRespawnSvc = session.tvtMatchId ? invoke('GameServer/World/ColiseumTvtService') : null;",
            "                if (tvtRespawnSvc) {",
            "                    const tvtCoord = tvtRespawnSvc.getRespawnCoord?.(bot);",
            "                    if (tvtCoord) {",
            "                        spawnTarget = tvtCoord;",
            "                    }",
            "                }",
            "                Generics.teleportTo(session, bot, spawnTarget);",
            "                if (tvtRespawnSvc?.isTvTParticipant?.(bot)) {",
            "                    tvtRespawnSvc.handleActorRespawn?.(session, bot);",
            '                    if (typeof bot.fetchMaxHp === \'function\' && typeof bot.setHp === \'function\') {',
            '                        bot.setHp(Number(bot.fetchMaxHp() || 0));',
            '                    }',
            '                    if (typeof bot.fetchMaxMp === \'function\' && typeof bot.setMp === \'function\') {',
            '                        bot.setMp(Number(bot.fetchMaxMp() || 0));',
            '                    }',
            '                    if (typeof bot.fetchMaxCp === \'function\' && typeof bot.setCp === \'function\') {',
            '                        bot.setCp(Number(bot.fetchMaxCp() || 0));',
            '                    }',
            '                    bot.fillupVitals?.();',
            '                    bot.statusUpdateVitals?.(bot);',
            "                }",
            "                ",
            "                this.say(session, getRandomPhrase('revived'), { ambient: true, key: 'revived' });",
            "            }",
            "            return;",
            "        }",
            '        const state = States[session.plan];'
        ].join('\n')
    }
];

for (const p of patches) {
    const fullTarget = path.join(targetRoot, p.rel);
    if (!fs.existsSync(fullTarget)) {
        console.warn('[AVISO] Arquivo nao encontrado no destino:', p.rel);
        continue;
    }
    backupFile(p.rel);
    const res = injectOnce(fullTarget, p.marker, p.anchor, p.replacement);
    console.log('[' + res.reason + ']', p.rel);
    if (res.changed) {
        execFileSync(process.execPath, ['--check', fullTarget], { stdio: 'inherit' });
    }
}

console.log('');
console.log('Concluido com sucesso! Backup salvo em:', backupDir);
