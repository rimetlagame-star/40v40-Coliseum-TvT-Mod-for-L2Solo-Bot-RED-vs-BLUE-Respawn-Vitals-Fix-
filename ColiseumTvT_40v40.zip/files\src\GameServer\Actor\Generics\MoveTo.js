const ServerResponse = invoke('GameServer/Network/Response');
const GeodataEngine  = invoke('GameServer/Geodata/GeodataEngine');
const EffectRestrictions = invoke('GameServer/Effects/EffectRestrictions');
const PopulationMetrics = invoke('GameServer/Bot/Population/PopulationMetrics');
const PathfindingWorkerPool = invoke('GameServer/Geodata/PathfindingWorkerPool');
const TownNavigation = invoke('GameServer/Bot/AI/TownNavigation');
const TownTransitPolicy = invoke('GameServer/Bot/AI/TownTransitPolicy');
const TownTraffic = invoke('GameServer/Bot/AI/TownTraffic');

// World.fetchVisibleUsers broadcasts movement to observers inside this same
// radius.  Low-detail simulation must never silently relocate a bot that is
// already visible to a player (or whose requested destination is visible).
const { CLIENT_VISIBILITY_RADIUS, inClientView } = invoke('GameServer/World/WorldConstants');
const COMPANION_DIRECT_DISTANCE = 256;
const COMPANION_PATH_TIMEOUT_MS = 2000;
const COMPANION_PATH_MAX_NODES = 4000;
const COMPANION_ERRAND_PATH_MAX_NODES = 120000;
const COMPANION_MAX_ARRIVAL_RADIUS = 512;
const ACTIVE_GOAL_XY_TOLERANCE = 32;
const ACTIVE_GOAL_Z_TOLERANCE = 64;
const INITIAL_WAYPOINT_SKIP_DISTANCE = 24;
const MOVE_PROGRESS_SAMPLE_MS = 750;
const MOVE_PROGRESS_DISTANCE = 8;
const MOVE_STALL_SAMPLES = 3;
const MOVEMENT_TRACE_LIMIT = 24;
const TOWN_NPC_EGRESS_MAX_AGE_MS = 120000;
const TOWN_NPC_EGRESS_START_TOLERANCE = 96;

function recordMovementTrace(session, entry) {
    if (!session || !(invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true)) return;
    if (!Array.isArray(session.movementTrace)) session.movementTrace = [];
    session.movementTrace.push({ at: Date.now(), ...entry });
    if (session.movementTrace.length > MOVEMENT_TRACE_LIMIT) {
        session.movementTrace.splice(0, session.movementTrace.length - MOVEMENT_TRACE_LIMIT);
    }
}

function locOf(actor) {
    return {
        locX: Number(actor.fetchLocX()),
        locY: Number(actor.fetchLocY()),
        locZ: Number(actor.fetchLocZ())
    };
}

function sameLoc(first, second, tolerance = 1) {
    return Math.abs(Number(first?.locX) - Number(second?.locX)) <= tolerance &&
        Math.abs(Number(first?.locY) - Number(second?.locY)) <= tolerance &&
        Math.abs(Number(first?.locZ) - Number(second?.locZ)) <= tolerance;
}

function sameMoveGoal(first, second) {
    return Math.abs(Number(first?.locX) - Number(second?.locX)) <= ACTIVE_GOAL_XY_TOLERANCE &&
        Math.abs(Number(first?.locY) - Number(second?.locY)) <= ACTIVE_GOAL_XY_TOLERANCE &&
        Math.abs(Number(first?.locZ) - Number(second?.locZ)) <= ACTIVE_GOAL_Z_TOLERANCE;
}

function rememberTownNpcEgress(session, requestedTo, routedTo, movementPath) {
    const approach = session?.townNpcApproach;
    if (approach?.phase !== 'interaction' || !String(approach.key || '').startsWith('shopping:')) return;
    if (!sameLoc(requestedTo, routedTo) || !Array.isArray(movementPath) || movementPath.length < 2) return;

    session.townNpcEgress = {
        key: approach.key,
        createdAt: Date.now(),
        path: movementPath.map((point) => ({ ...point })).reverse()
    };
}

function takeTownNpcEgress(session, start) {
    const egress = session?.townNpcEgress;
    if (!egress) return null;
    // A completed ingress path is also useful for leaving the shop, but only
    // after the interaction has finished. Replaying it while the same approach
    // is active makes a bot bounce between the counter and the street whenever
    // the last path node happens to lack line of sight to the NPC.
    const approach = session?.townNpcApproach;
    if (approach?.phase === 'interaction' && approach.key === egress.key) return null;
    delete session.townNpcEgress;
    if (Date.now() - Number(egress.createdAt || 0) > TOWN_NPC_EGRESS_MAX_AGE_MS) return null;
    if (!Array.isArray(egress.path) || egress.path.length < 2) return null;

    const pathStart = egress.path[0];
    if (distance2d(start, pathStart) > TOWN_NPC_EGRESS_START_TOLERANCE) return null;
    if (Math.abs(Number(start.locZ) - Number(pathStart.locZ)) > ACTIVE_GOAL_Z_TOLERANCE) return null;
    return egress;
}

function activeMoveGoal(session, actor, now = Date.now()) {
    if (!session?.activeMoveGoal) return null;
    if (session.pendingPathRequest) return session.activeMoveGoal;
    if (!session.moveTimer) return null;

    const goal = session.activeMoveGoal;
    if (now - Number(goal.lastProgressSampleAt || 0) < MOVE_PROGRESS_SAMPLE_MS) return goal;

    const current = locOf(actor);
    const previous = goal.lastProgressLoc || current;
    const progressed = distance2d(current, previous) >= MOVE_PROGRESS_DISTANCE;
    goal.lastProgressSampleAt = now;
    if (progressed) {
        goal.lastProgressLoc = current;
        goal.stalledSamples = 0;
        return goal;
    }

    goal.stalledSamples = Number(goal.stalledSamples || 0) + 1;
    return goal.stalledSamples >= MOVE_STALL_SAMPLES ? null : goal;
}

function beginMoveGoal(session, actor, requestedTo, targetActor = null, routeGuard = null) {
    const goal = {
        generation: Number(session.moveRouteGeneration || 0),
        requestedTo: { ...requestedTo },
        targetId: Number(targetActor?.fetchId?.()) || null,
        routeGuard,
        startedAt: Date.now(),
        lastProgressSampleAt: Date.now(),
        lastProgressLoc: locOf(actor),
        stalledSamples: 0
    };
    session.activeMoveGoal = goal;
    return goal;
}

function clearMoveGoal(session, goal) {
    if (session?.activeMoveSegment?.goal === goal) session.activeMoveSegment = null;
    if (session && goal && session.activeMoveGoal === goal) session.activeMoveGoal = null;
}

function movementSpeed(actor) {
    return Math.max(1, Number(actor.state?.fetchWalkin?.() === true
        ? actor.fetchCollectiveWalkSpd?.() : actor.fetchCollectiveRunSpd?.()) || 120);
}

function shouldSkipInitialWaypoint(index, path, distance, dz) {
    return index === 0 &&
        path.length > 1 &&
        distance <= INITIAL_WAYPOINT_SKIP_DISTANCE &&
        Math.abs(dz) <= ACTIVE_GOAL_Z_TOLERANCE;
}

function startPathMovement({ session, actor, path, isClose, approachingObservers, moveGoal }) {
    const routeAllowed = (route, complete) => !moveGoal?.routeGuard || moveGoal.routeGuard(route, { complete }) !== false;
    const rejectRoute = () => {
        session.lastPathfinding.routeUsable = false;
        session.lastPathfinding.movementRejected = true;
        actor.state.setTowards(false);
        clearMoveGoal(session, moveGoal);
    };
    if (!routeAllowed(path, true)) {
        rejectRoute();
        return;
    }
    const moveAlongPath = (index) => {
        if (moveGoal && session.activeMoveGoal !== moveGoal) return;
        if (index >= path.length) {
            if (moveGoal?.town) TownTraffic.remove(Number(actor.fetchId()));
            session.moveTimer = null;
            actor.state.setTowards(false);
            clearMoveGoal(session, moveGoal);
            return;
        }

        const currentLoc = locOf(actor);
        const nextLoc = { ...path[index] };
        // A direct path can retain the caller's old Z. Use the same geodata
        // layer for the announced destination, interpolation and arrival;
        // otherwise each completed leg snaps the body back below the ground.
        nextLoc.locZ = GeodataEngine.getHeight(nextLoc.locX, nextLoc.locY, nextLoc.locZ);
        // Recheck live party position and new hazards between native legs.
        if (!routeAllowed([currentLoc, nextLoc], false)) {
            rejectRoute();
            return;
        }
        const dx = nextLoc.locX - currentLoc.locX;
        const dy = nextLoc.locY - currentLoc.locY;
        const dz = nextLoc.locZ - currentLoc.locZ;
        const distance = Math.sqrt(dx * dx + dy * dy);

        // A* begins at the centre of the actor's current 16-unit geodata cell.
        // Announcing that tiny correction before the real leg makes C4 briefly
        // turn or stop at the start of every route. Keep the authoritative
        // current coordinate and begin with the first meaningful waypoint.
        if (shouldSkipInitialWaypoint(index, path, distance, dz)) {
            moveAlongPath(index + 1);
            return;
        }

        if (distance === 0) {
            actor.setLocXYZ(nextLoc);
            invoke('GameServer/Bot/AI/PartyCompanionService').updatePosition(session, actor);
            moveAlongPath(index + 1);
            return;
        }

        const speed = movementSpeed(actor);
        const duration = Math.max(1, (distance / speed) * 1000);
        const segmentStartedAt = Date.now();
        const segment = session.activeMoveSegment = { actor, goal: moveGoal, to: nextLoc,
            speed, updatedAt: segmentStartedAt, travelled: 0 };
        const segmentCoords = { from: currentLoc, to: nextLoc };
        const movePacket = ServerResponse.moveToLocation(actor.fetchId(), segmentCoords, actor);
        session.dataSendToMeAndOthers(movePacket, actor);
        approachingObservers.forEach((observer) => {
            const observerSession = observer.session;
            if (!observerSession?.actor?.fetchIsOnline?.() || !observerSession.dataSendToMe) return;
            if (inClientView(observerSession.actor.fetchLocX(), observerSession.actor.fetchLocY(),
                currentLoc.locX, currentLoc.locY)) return;
            if (!crossesPlayerVisibility(observerSession.actor, currentLoc, nextLoc)) return;
            if (!observer.announced) {
                const info = ServerResponse.charInfo(actor);
                info.__skipMotionReplay = true;
                observerSession.dataSendToMe(info);
                observer.announced = true;
            }
            observerSession.dataSendToMe(movePacket);
        });

        const tickRate = isClose ? 100 : 250;
        if (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true) recordMovementTrace(session, {
            event: 'move',
            index,
            pathLength: path.length,
            from: { ...currentLoc },
            to: { ...nextLoc },
            distance,
            speed,
            duration,
            baseRunSpeed: Number(actor.fetchRunSpd?.()) || 0,
            walking: actor.state?.fetchWalkin?.() === true
        });

        const advanceSegment = () => {
            if (!session.moveTimer || (moveGoal && session.activeMoveGoal !== moveGoal)) return;
            const now = Date.now();
            const elapsed = Math.max(0, now - segmentStartedAt);
            // Effects and run/walk changes can alter speed halfway through a
            // leg. Integrate distance at the body's current speed rather than
            // retaining the duration from before its latest CharInfo.
            segment.speed = movementSpeed(actor);
            segment.travelled += Math.max(0, now - segment.updatedAt) * segment.speed / 1000;
            segment.updatedAt = now;
            const ratio = Math.min(1, segment.travelled / distance);
            if (ratio >= 1) {
                actor.setLocXYZ(nextLoc);
                invoke('GameServer/Bot/AI/PartyCompanionService').updatePosition(session, actor);
                session.moveTimer = null;
                if (session.activeMoveSegment === segment) session.activeMoveSegment = null;
                if (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true) recordMovementTrace(session, {
                    event: 'arrive',
                    index,
                    pathLength: path.length,
                    to: { ...nextLoc },
                    elapsed,
                    duration
                });
                moveAlongPath(index + 1);
            } else {
                const nextX = Math.round(currentLoc.locX + dx * ratio);
                const nextY = Math.round(currentLoc.locY + dy * ratio);
                const nextZ = Math.round(currentLoc.locZ + dz * ratio);
                const snappedZ = GeodataEngine.getHeight(nextX, nextY, nextZ);
                actor.setLocXYZ({ locX: nextX, locY: nextY, locZ: snappedZ });
                invoke('GameServer/Bot/AI/PartyCompanionService').updatePosition(session, actor);
                if (moveGoal?.town) {
                    const point = locOf(actor);
                    TownTraffic.update(Number(actor.fetchId()), point, nextLoc, segment.speed);
                    const adjustment = TownTraffic.steer(session, actor, point, nextLoc,
                        distanceToClosestPlayer(moveGoal.observers || [], point));
                    if (adjustment?.point) {
                        path.splice(index, 0, adjustment.point);
                        moveAlongPath(index);
                        return;
                    }
                    if (adjustment?.waitMs) {
                        if (session.activeMoveSegment === segment) session.activeMoveSegment = null;
                        TownTraffic.update(Number(actor.fetchId()), point);
                        session.dataSendToMeAndOthers(ServerResponse.stopMove(actor.fetchId(), {
                            ...point, head: actor.fetchHead?.() || 0
                        }), actor);
                        session.moveTimer = setTimeout(() => moveAlongPath(index), adjustment.waitMs);
                        return;
                    }
                }
                const remaining = Math.max(1, (distance - segment.travelled) / segment.speed * 1000);
                session.moveTimer = setTimeout(advanceSegment, Math.min(tickRate, remaining));
            }
        };

        session.moveTimer = setTimeout(advanceSegment, Math.min(tickRate, duration));
    };

    actor.state.setTowards('move');
    moveAlongPath(0);
}

function distanceToClosestPlayer(players, coords) {
    if (!players.length) return Infinity;

    return players.reduce((closest, player) => {
        const dx = player.fetchLocX() - coords.locX;
        const dy = player.fetchLocY() - coords.locY;
        return Math.min(closest, Math.sqrt(dx * dx + dy * dy));
    }, Infinity);
}

function distance2d(first, second) {
    const dx = Number(first?.fetchLocX?.() ?? first?.locX ?? 0) - Number(second?.fetchLocX?.() ?? second?.locX ?? 0);
    const dy = Number(first?.fetchLocY?.() ?? first?.locY ?? 0) - Number(second?.fetchLocY?.() ?? second?.locY ?? 0);
    return Math.sqrt((dx * dx) + (dy * dy));
}

function crossesPlayerVisibility(player, from, to) {
    const dx = to.locX - from.locX, dy = to.locY - from.locY;
    const lengthSquared = dx * dx + dy * dy;
    const px = player.fetchLocX() - from.locX, py = player.fetchLocY() - from.locY;
    const t = lengthSquared > 0 ? Math.max(0, Math.min(1, (px * dx + py * dy) / lengthSquared)) : 0;
    return inClientView(px, py, t * dx, t * dy);
}

function shouldUseLowLodWarp({ startDistance, destinationDistance, isCompanion, plan, crossesVisibility = false }) {
    return !isCompanion &&
        !crossesVisibility &&
        plan !== 'pk_hunting' &&
        startDistance > CLIENT_VISIBILITY_RADIUS &&
        destinationDistance > CLIENT_VISIBILITY_RADIUS;
}

function shouldPreannounceVisibleMove(startDistance, destinationDistance, crossesVisibility = false) {
    return startDistance > CLIENT_VISIBILITY_RADIUS
        && (destinationDistance <= CLIENT_VISIBILITY_RADIUS || crossesVisibility);
}

function previewRouteSession(session) {
    if (!session) return session;
    const plan = session.townRoutePlan;
    return {
        ...session,
        townRoutePlan: plan ? {
            ...plan,
            finalTarget: plan.finalTarget ? { ...plan.finalTarget } : plan.finalTarget,
            waypoint: plan.waypoint ? { ...plan.waypoint } : plan.waypoint
        } : plan
    };
}

function moveTo(session, actor, coords) {
    const previewOnly = coords.previewOnly === true;
    if (!previewOnly && actor.isDead()) {
        return;
    }

    if (!previewOnly && !EffectRestrictions.canMove(actor)) {
        EffectRestrictions.reject(session);
        return;
    }

    if (!previewOnly) {
        // Record the command before queuing it behind a swing/cast. Older
        // async target lookups must not replace this newer movement request.
        actor.moveRequestGeneration = Number(actor.moveRequestGeneration || 0) + 1;
        // Lisvus replaces the attack intention on movement. Keep bow reuse
        // timing, but forget a repeat requested before this ground click.
        if (actor.attack) actor.attack.repeatTarget = null;
    }

    if (!previewOnly && actor.isBlocked()) {
        invoke(path.actor).queueRequest(session, actor, 'move', coords);
        return;
    }
    const tvtSvc = invoke('GameServer/World/ColiseumTvtService');
    const tvtActiveMatch = tvtSvc?.getActiveMatch?.();
    if (tvtActiveMatch && (session?.tvtMatchId === tvtActiveMatch.id || tvtSvc?.isTvTParticipant?.(actor))) {
        if (coords?.to && typeof tvtSvc.clampToArena === 'function') {
            const clampedTo = tvtSvc.clampToArena(coords.to.locX, coords.to.locY, coords.to.locZ);
            coords = {
                ...coords,
                to: {
                    ...coords.to,
                    locX: clampedTo.locX,
                    locY: clampedTo.locY,
                    locZ: clampedTo.locZ
                }
            };
        }
        if (coords?.from && typeof tvtSvc.isInsideArena === 'function' && typeof tvtSvc.clampToArena === 'function') {
            if (!tvtSvc.isInsideArena(coords.from.locX, coords.from.locY, coords.from.locZ)) {
                const clampedFrom = tvtSvc.clampToArena(coords.from.locX, coords.from.locY, coords.from.locZ);
                coords = {
                    ...coords,
                    from: {
                        ...coords.from,
                        locX: clampedFrom.locX,
                        locY: clampedFrom.locY,
                        locZ: clampedFrom.locZ
                    }
                };
            }
        }
    }

    const isBot = session && (session.constructor.name === 'BotSession' || (session.accountId && session.accountId.startsWith('bot_')));
    const requestedTo = { ...coords.to };
    const arrivalRadius = Math.min(COMPANION_MAX_ARRIVAL_RADIUS, Math.max(0, Number(coords.arrivalRadius || 0)));
    const pathMaxNodes = Math.min(
        COMPANION_ERRAND_PATH_MAX_NODES,
        Math.max(COMPANION_PATH_MAX_NODES, Number(coords.pathMaxNodes || COMPANION_PATH_MAX_NODES))
    );
    let townRouteDiagnostics = null;

    // Hot AI states may evaluate the same fixed destination every second. A
    // repeated command to the active goal must not abort movement, rerun A*,
    // or broadcast StopMove + MoveToLocation again. Recovery callers can
    // explicitly replace a healthy-looking route with forceRepath.
    if (!previewOnly && isBot && coords.forceRepath !== true) {
        const activeGoal = activeMoveGoal(session, actor);
        if (activeGoal && sameMoveGoal(activeGoal.requestedTo, requestedTo)) {
            return session.lastPathfinding;
        }
    }

    // A route preview must not alter the actor or emit a false movement packet.
    if (!previewOnly) {
        // Abort scheduled movement, user redirected the actor
        actor.automation.abortAll(actor);
    }

    if (!isBot) {
        // Normal player movement
        coords = { ...coords, to: require('../../Geodata/GardenOfEvaBarriers').clip(coords.from, coords.to) };
        session.dataSendToMeAndOthers(ServerResponse.moveToLocation(actor.fetchId(), coords), actor);
    } else {
        // Bot movement
        const startX = coords.from.locX;
        const startY = coords.from.locY;
        const startZ = coords.from.locZ;

        // Keep low-detail simulation outside the client-visible area.  The
        // old 1500-unit threshold was much smaller than the 6000-unit world
        // visibility radius, so a bot could be visibly running and then have
        // its server position silently overwritten.
        const World = invoke('GameServer/World/World');
        const onlinePlayerSessions = World.user.sessions
            .filter(s =>
                s.actor &&
                s.actor.fetchIsOnline() &&
                s.accountId &&
                !s.accountId.startsWith('bot_')
            );
        const onlinePlayers = onlinePlayerSessions.map((playerSession) => playerSession.actor);
        const distanceToPlayer = distanceToClosestPlayer(onlinePlayers, {
            locX: startX,
            locY: startY
        });
        const destinationDistanceToPlayer = distanceToClosestPlayer(onlinePlayers, requestedTo);
        const routeVisibleTo = new Set(onlinePlayers.filter(player => crossesPlayerVisibility(player, coords.from, requestedTo)));
        // Movement packets are normally broadcast from the bot's current
        // coordinates. A player who is just outside that radius would miss
        // the first packet and only discover the bot through a later refresh,
        // which looks like a teleport. Prime that observer before the route
        // crosses into their visible area.
        const approachingObservers = onlinePlayerSessions
            .filter((playerSession) => shouldPreannounceVisibleMove(
                distance2d(playerSession.actor, { locX: startX, locY: startY }),
                distance2d(playerSession.actor, requestedTo),
                routeVisibleTo.has(playerSession.actor)
            ))
            .map((playerSession) => ({ session: playerSession, announced: false }));

        const isCompanion = !!session.followPlayerSession && session.partyCompanion === true;
        // Town errands explicitly request a larger search budget. Running that
        // A* synchronously stalls the game loop when several hot bots navigate
        // a city at once, so share the bounded companion worker pool for those
        // expensive autonomous routes as well.
        const useWorkerPathfinding = isCompanion || pathMaxNodes > COMPANION_PATH_MAX_NODES;
        const useSegmentedTownRoute = pathMaxNodes > COMPANION_PATH_MAX_NODES;
        const townName = useSegmentedTownRoute
            ? TownTransitPolicy.routeTown({ locX: startX, locY: startY, locZ: startZ }, requestedTo) : null;

        if (!townName && shouldUseLowLodWarp({
            startDistance: distanceToPlayer,
            destinationDistance: destinationDistanceToPlayer,
            isCompanion,
            plan: session.plan,
            crossesVisibility: routeVisibleTo.size > 0
        })) {
            // Low LOD: instant warp (we do not calculate movements at all)
            const snappedTo = { ...requestedTo };
            snappedTo.locZ = GeodataEngine.getHeight(snappedTo.locX, snappedTo.locY, snappedTo.locZ);
            session.lastPathfinding = {
                requestedTo,
                routedTo: { ...snappedTo },
                ...(previewOnly ? { route: [{ ...snappedTo }] } : {}),
                townRoute: null,
                pathLength: 0,
                routeUsable: true,
                lowLodWarp: true,
                distanceToPlayer,
                destinationDistanceToPlayer,
                strategy: 'low_lod_direct',
                at: Date.now()
            };
            if (previewOnly) return session.lastPathfinding;
            actor.setLocXYZ(snappedTo);
            invoke('GameServer/Bot/AI/PartyCompanionService').updatePosition(session, actor);
            return session.lastPathfinding;
        }

        const isClose = isCompanion || distanceToPlayer <= 500;

        let pathTarget = { ...requestedTo };
        const pathStartedAt = invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true ? Date.now() : null;
        const moveGoal = previewOnly ? null : beginMoveGoal(session, actor, requestedTo, coords.targetActor, coords.routeGuard);
        if (moveGoal && townName) {
            moveGoal.town = townName;
            moveGoal.observers = onlinePlayers;
        }

        if (useSegmentedTownRoute && !previewOnly) {
            const egress = takeTownNpcEgress(session, { locX: startX, locY: startY, locZ: startZ });
            if (egress) {
                const routedTo = { ...egress.path[egress.path.length - 1] };
                session.townRoutePlan = null;
                session.lastPathfinding = {
                    requestedTo,
                    routedTo,
                    townRoute: (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true) ? {
                        from: { locX: startX, locY: startY, locZ: startZ },
                        to: { ...requestedTo },
                        routedTo: { ...routedTo },
                        fromTown: null,
                        toTown: null,
                        changedTarget: true,
                        plan: null,
                        reason: 'reverse_shop_ingress',
                        shopKey: egress.key
                    } : { changedTarget: true },
                    pathLength: egress.path.length,
                    routeUsable: true,
                    lowLodWarp: false,
                    distanceToPlayer,
                    destinationDistanceToPlayer,
                    strategy: 'town_shop_egress',
                    worker: false,
                    arrivalRadius,
                    maxNodes: 0,
                    at: Date.now()
                };
                startPathMovement({
                    session,
                    actor,
                    path: egress.path,
                    isClose,
                    approachingObservers,
                    moveGoal
                });
                return session.lastPathfinding;
            }
        }

        if (useWorkerPathfinding && !previewOnly) {
            const rawPool = session.pathfindingWorkerPool || PathfindingWorkerPool;
            const pool = townName ? TownNavigation.forPool(rawPool) : rawPool;
            let pathArrivalRadius = arrivalRadius;
            const routeGeneration = Number(session.moveRouteGeneration || 0);
            const actorId = Number(actor.fetchId());
            const leaderSession = session.followPlayerSession;
            const targetActor = coords.targetActor || null;
            const targetId = Number(targetActor?.fetchId?.()) || null;
            const targetStart = targetActor ? locOf(targetActor) : null;
            const start = { locX: startX, locY: startY, locZ: startZ };
            if (useSegmentedTownRoute) {
                const TownPathfinder = invoke('GameServer/Bot/AI/TownPathfinder');
                const routeResult = TownPathfinder.routeWithSession(session, townName ? null : actor, start, requestedTo);
                pathTarget = { ...routeResult.to };
                pathArrivalRadius = routeResult.arrivalRadius ?? arrivalRadius;
                townRouteDiagnostics = routeResult.diagnostics;
                coords.to.locX = pathTarget.locX;
                coords.to.locY = pathTarget.locY;
                coords.to.locZ = pathTarget.locZ;
            }
            const requestKey = `${isCompanion ? 'companion' : 'bot'}:${actorId}`;
            const clearPending = ({ clearGoal = false } = {}) => {
                const pending = session.pendingPathRequest;
                if (pending?.key === requestKey && pending.generation === routeGeneration) {
                    session.pendingPathRequest = null;
                    if (actor.state?.fetchTowards?.() === 'path') actor.state.setTowards(false);
                }
                if (clearGoal) clearMoveGoal(session, moveGoal);
            };
            const isCurrent = () => (
                Number(session.moveRouteGeneration || 0) === routeGeneration &&
                (!isCompanion || (
                    session.partyCompanion === true &&
                    session.followPlayerSession === leaderSession
                )) &&
                session.actor === actor &&
                Number(actor.fetchId()) === actorId &&
                (!targetActor || (
                    Number(targetActor.fetchId?.()) === targetId &&
                    targetActor.fetchIsOnline?.() !== false &&
                    (targetActor.isDead?.() !== true || (coords.allowDeadTarget === true
                        && targetActor.corpseDecayState !== 'removed'
                        && Number(targetActor.corpseDecayAt || Infinity) > Date.now())) &&
                    sameLoc(locOf(targetActor), targetStart, 128)
                )) &&
                !actor.isDead() &&
                EffectRestrictions.canMove(actor) &&
                sameLoc(locOf(actor), start) &&
                sameLoc(coords.to, pathTarget)
            );
            const finish = (candidatePath, strategy, error = null) => {
                if (!isCurrent()) {
                    clearPending({ clearGoal: true });
                    return null;
                }
                clearPending();
                const routeFound = Array.isArray(candidatePath) && candidatePath.length > 1;
                const fallbackLineOfSight = !routeFound && GeodataEngine.canWalkStraight(
                    startX, startY, startZ,
                    pathTarget.locX, pathTarget.locY, pathTarget.locZ
                );
                const movementPath = routeFound
                    ? candidatePath
                    : (fallbackLineOfSight ? [{ ...pathTarget }] : []);
                if (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true) PopulationMetrics.recordPathfindingDuration(isCompanion ? 'companion' : 'actor', Date.now() - pathStartedAt);
                session.lastPathfinding = {
                    requestedTo,
                    routedTo: { ...pathTarget },
                    townRoute: townRouteDiagnostics,
                    pathLength: movementPath.length,
                    routeUsable: routeFound || fallbackLineOfSight,
                    lowLodWarp: false,
                    distanceToPlayer,
                    destinationDistanceToPlayer,
                    strategy,
                    worker: true,
                    arrivalRadius: pathArrivalRadius,
                    maxNodes: pathMaxNodes,
                    ...(townName && (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true) ? { townNavigation: pool.stats() } : {}),
                    ...(error ? { error: error.code || error.message || String(error) } : {}),
                    at: Date.now()
                };
                if (movementPath.length) {
                    rememberTownNpcEgress(session, requestedTo, pathTarget, movementPath);
                    startPathMovement({ session, actor, path: movementPath, isClose, approachingObservers, moveGoal });
                } else {
                    clearMoveGoal(session, moveGoal);
                }
                return session.lastPathfinding;
            };
            const requestPath = (target, strategy) => pool.request({
                startX, startY, startZ,
                endX: target.locX,
                endY: target.locY,
                endZ: target.locZ,
                maxNodes: pathMaxNodes,
                goalRadius: pathArrivalRadius,
                ...(townName ? { town: townName } : {}),
                goalZTolerance: ACTIVE_GOAL_Z_TOLERANCE
            }, {
                key: requestKey,
                priority: isCompanion ? 100 : 50,
                timeoutMs: COMPANION_PATH_TIMEOUT_MS
            }).then((candidatePath) => {
                if (!isCurrent()) {
                    clearPending({ clearGoal: true });
                    return null;
                }
                if (Array.isArray(candidatePath) && candidatePath.length > 1) {
                    if (sameLoc(target, requestedTo)) session.townRoutePlan = null;
                    return finish(candidatePath, strategy);
                }

                // A segmented request already targets one bounded waypoint.
                // Retrying that same point inside this dispatch only doubles
                // the work; let recovery rotate the waypoint-area sample.
                if (!sameLoc(target, requestedTo)) {
                    return finish(candidatePath, `${strategy}_unreachable`);
                }

                const TownPathfinder = invoke('GameServer/Bot/AI/TownPathfinder');
                const routeResult = TownPathfinder.routeWithSession(session, townName ? null : actor, start, requestedTo);
                pathTarget = { ...routeResult.to };
                townRouteDiagnostics = routeResult.diagnostics;
                const waypointArrivalRadius = Number.isFinite(routeResult.arrivalRadius)
                    ? Math.max(0, Number(routeResult.arrivalRadius))
                    : arrivalRadius;
                coords.to.locX = pathTarget.locX;
                coords.to.locY = pathTarget.locY;
                coords.to.locZ = pathTarget.locZ;
                const fallbackStrategy = townRouteDiagnostics?.changedTarget
                    ? 'worker_town_waypoint_fallback'
                    : 'worker_direct_fallback';
                if (sameLoc(pathTarget, requestedTo)) return finish(candidatePath, fallbackStrategy);
                return pool.request({
                    startX, startY, startZ,
                    endX: pathTarget.locX,
                    endY: pathTarget.locY,
                    endZ: pathTarget.locZ,
                    maxNodes: pathMaxNodes,
                    goalRadius: waypointArrivalRadius,
                    ...(townName ? { town: townName } : {}),
                    goalZTolerance: ACTIVE_GOAL_Z_TOLERANCE
                }, {
                    key: requestKey,
                    priority: isCompanion ? 100 : 50,
                    timeoutMs: COMPANION_PATH_TIMEOUT_MS
                }).then((fallbackPath) => finish(fallbackPath, fallbackStrategy));
            }).catch((error) => {
                if (error?.code === 'STALE_PATH' || !isCurrent()) {
                    clearPending({ clearGoal: true });
                    return null;
                }
                return finish(null, `${strategy}_error_fallback`, error);
            });

            session.pendingPathRequest = {
                key: requestKey,
                generation: routeGeneration,
                requestedTo: { ...requestedTo },
                cancel: () => pool.cancel(requestKey),
                promise: null
            };

            const directDistance = distance2d(start, requestedTo);
            if (directDistance <= COMPANION_DIRECT_DISTANCE && GeodataEngine.canWalkStraight(
                startX, startY, startZ,
                requestedTo.locX, requestedTo.locY, requestedTo.locZ
            )) {
                session.pendingPathRequest = null;
                return finish([{ ...start }, { ...requestedTo }], 'short_direct');
            }

            session.pendingPathRequest.promise = requestPath(
                pathTarget,
                townRouteDiagnostics?.changedTarget ? 'worker_town_segment' : 'worker_geodata'
            );
            actor.state.setTowards('path');
            session.lastPathfinding = {
                requestedTo,
                routedTo: { ...pathTarget },
                townRoute: townRouteDiagnostics,
                pathLength: 0,
                routeUsable: null,
                lowLodWarp: false,
                distanceToPlayer,
                destinationDistanceToPlayer,
                strategy: 'worker_pending',
                worker: true,
                arrivalRadius: pathArrivalRadius,
                maxNodes: pathMaxNodes,
                at: Date.now()
            };
            return session.lastPathfinding;
        }

        let path = GeodataEngine.findPath(
            startX, startY, startZ,
            requestedTo.locX, requestedTo.locY, requestedTo.locZ,
            undefined,
            { debug: false }
        );
        let pathStrategy = 'direct_geodata';

        if (!path || path.length <= 1) {
            const TownPathfinder = invoke('GameServer/Bot/AI/TownPathfinder');
            const routeSession = previewOnly ? previewRouteSession(session) : session;
            const routeResult = TownPathfinder.routeWithSession(routeSession, actor, coords.from, requestedTo);
            pathTarget = { ...routeResult.to };
            townRouteDiagnostics = routeResult.diagnostics;
            if (!previewOnly) {
                coords.to.locX = pathTarget.locX;
                coords.to.locY = pathTarget.locY;
                coords.to.locZ = pathTarget.locZ;
            }
            pathStrategy = townRouteDiagnostics?.changedTarget ? 'town_waypoint_fallback' : 'direct_fallback';

            path = GeodataEngine.findPath(
                startX, startY, startZ,
                pathTarget.locX, pathTarget.locY, pathTarget.locZ,
                undefined,
                { debug: false }
            );
        } else if (session && !previewOnly) {
            session.townRoutePlan = null;
        }

        const routeFound = Array.isArray(path) && path.length > 1;
        if (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true) PopulationMetrics.recordPathfindingDuration(isCompanion ? 'companion' : 'actor', Date.now() - pathStartedAt);
        // A* is deliberately bounded and can return null in otherwise open
        // terrain. The runtime has always handled that case with a direct
        // movement fallback, so distinguish a clear line from a genuinely
        // blocked destination before callers decide to reject the route.
        const fallbackLineOfSight = !routeFound && GeodataEngine.canWalkStraight(
            startX, startY, startZ,
            pathTarget.locX, pathTarget.locY, pathTarget.locZ
        );
        if (!routeFound) {
            // Never announce a straight segment through blocked geodata. In a
            // multilevel town cell that can also snap the authoritative Z to
            // a roof while the C4 client remains on the street, stretching
            // its animation until the next packet visibly corrects it.
            path = fallbackLineOfSight
                ? [{ locX: pathTarget.locX, locY: pathTarget.locY, locZ: pathTarget.locZ }]
                : [];
        }
        session.lastPathfinding = {
            requestedTo,
            routedTo: { ...pathTarget },
            ...(previewOnly ? { route: path.map((waypoint) => ({ ...waypoint })) } : {}),
            townRoute: townRouteDiagnostics,
            pathLength: path.length,
            routeUsable: routeFound || fallbackLineOfSight,
            lowLodWarp: false,
            distanceToPlayer,
            destinationDistanceToPlayer,
            strategy: pathStrategy,
            at: Date.now()
        };
        if (previewOnly) {
            return session.lastPathfinding;
        }
        if (path.length > 0) {
            rememberTownNpcEgress(session, requestedTo, pathTarget, path);
            startPathMovement({ session, actor, path, isClose, approachingObservers, moveGoal });
        } else {
            clearMoveGoal(session, moveGoal);
        }
        return session.lastPathfinding;
    }
}

module.exports = moveTo;
module.exports.recordMovementTrace = recordMovementTrace;
module.exports.shouldUseLowLodWarp = shouldUseLowLodWarp;
module.exports.shouldPreannounceVisibleMove = shouldPreannounceVisibleMove;
module.exports.crossesPlayerVisibility = crossesPlayerVisibility;
module.exports.CLIENT_VISIBILITY_RADIUS = CLIENT_VISIBILITY_RADIUS;
module.exports.COMPANION_DIRECT_DISTANCE = COMPANION_DIRECT_DISTANCE;
module.exports.COMPANION_PATH_MAX_NODES = COMPANION_PATH_MAX_NODES;
module.exports.COMPANION_ERRAND_PATH_MAX_NODES = COMPANION_ERRAND_PATH_MAX_NODES;
module.exports.ACTIVE_GOAL_XY_TOLERANCE = ACTIVE_GOAL_XY_TOLERANCE;
module.exports.INITIAL_WAYPOINT_SKIP_DISTANCE = INITIAL_WAYPOINT_SKIP_DISTANCE;
module.exports.MOVE_STALL_SAMPLES = MOVE_STALL_SAMPLES;
