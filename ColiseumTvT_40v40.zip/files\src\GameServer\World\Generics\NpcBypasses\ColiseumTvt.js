const ServerResponse = invoke('GameServer/Network/Response');
const Html = invoke('GameServer/World/Generics/HtmlKit');
const ColiseumTvtService = invoke('GameServer/World/ColiseumTvtService');

function sendNotice(session, msg) {
    if (!session || typeof session.dataSendToMe !== 'function') return;
    if (typeof ServerResponse?.say === 'function') {
        session.dataSendToMe(ServerResponse.say(msg, 'ColiseumTvT'));
    } else {
        session.dataSendToMe({ text: msg, sender: 'ColiseumTvT' });
    }
}

function btn(label, action, width = 110, height = 22) {
    return `<button value="${Html.esc(label)}" action="bypass -h ${Html.esc(action)}" width=${width} height=${height} back="sek.cbui94" fore="sek.cbui92">`;
}

function openScoreboard(session, reportOverride = null, pageArg = 1) {
    if (!session?.actor) return;
    const report = reportOverride || ColiseumTvtService.getLastMatchReport();
    if (!report || !Array.isArray(report.scoreboard) || report.scoreboard.length === 0) {
        sendNotice(session, '[Coliseum TvT] Ainda nao ha placar de partida encerrada para exibir.');
        return;
    }

    const pageSize = 15;
    const totalRows = report.scoreboard.length;
    const totalPages = Math.max(1, Math.ceil(totalRows / pageSize));
    const page = Math.max(1, Math.min(totalPages, Number(pageArg || 1) || 1));
    const startIdx = (page - 1) * pageSize;
    const slice = report.scoreboard.slice(startIdx, startIdx + pageSize);

    const rowsHtml = slice.map(function (row, offset) {
        const pos = startIdx + offset + 1;
        const col = row.team === 'RED' ? 'FF6666' : '66AAFF';
        return "<tr>" +
            "<td>" + pos + "</td>" +
            "<td>" + Html.esc(String(row.name || "-").slice(0, 14)) + "</td>" +
            "<td><font color=\"" + col + "\">" + Html.esc(row.team) + "</font></td>" +
            "<td align=\"right\">" + Number(row.kills || 0) + "</td>" +
            "<td align=\"right\">" + Number(row.deaths || 0) + "</td>" +
            "</tr>";
    }).join("");

    const headerHtml = "<tr><td><b>#</b></td><td><b>Nome</b></td><td><b>Time</b></td><td align=\"right\"><b>K</b></td><td align=\"right\"><b>D</b></td></tr>";

    const prevPage = Math.max(1, page - 1);
    const nextPage = Math.min(totalPages, page + 1);
    const navCells = [];
    if (totalPages > 1) {
        navCells.push("<td>" + btn("Ant", "coliseum-tvt scoreboard " + prevPage, 56, 20) + "</td>");
        navCells.push("<td>" + btn("Prox", "coliseum-tvt scoreboard " + nextPage, 56, 20) + "</td>");
    }
    navCells.push("<td>" + btn("Painel", "coliseum-tvt", 66, 20) + "</td>");

    const body =
        Html.font("Placar Coliseum TvT", Html.COLOR.title) + "<br>" +
        "<b>" + Html.esc(report.winner || "Encerrado") + "</b> (" + Html.esc(report.elapsedLabel || "00:00") + ")<br>" +
        "Total: " + totalRows + " | Pag " + page + "/" + totalPages + "<br><br>" +
        "<table width=250 cellpadding=1 cellspacing=0>" + headerHtml + rowsHtml + "</table><br>" +
        "<table cellpadding=1 cellspacing=1><tr>" + navCells.join("") + "</tr></table>";

    session.dataSendToMe(
        ServerResponse.npcHtml(session.actor.fetchId(), Html.page(body, { title: "Placar TvT" }))
    );
}

function renderPanel(session, statusOverride = null) {
    if (!session?.actor) return;
    const st = statusOverride || ColiseumTvtService.getStatusSummary();
    const stateLabel = st.active ? '<font color="66FF66">ATIVO</font>' : '<font color="FF6666">INATIVO</font>';

    const body = [
        `${Html.font('Antigo Coliseum - TvT', Html.COLOR.title)}<br>`,
        Html.statusTable([
            ['Estado', st.active ? 'ATIVO' : 'INATIVO'],
            ['Duracao', Html.esc(st.durationLabel || '05:00')],
            ['Decorrido', Html.esc(st.elapsedLabel || '00:00')],
            ['Restante', Html.esc(st.remainingLabel || '00:00')],
            ['Equipes', Html.esc(st.counter)],
            ['Placar RED', String(st.redKills ?? 0)],
            ['Placar BLUE', String(st.blueKills ?? 0)]
        ]),
        '<br>',
        `Status: ${stateLabel}<br>`,
        `<table width=240 cellpadding=2 cellspacing=2>`,
        `<tr><td align="center">${btn('Iniciar 5x5', 'coliseum-tvt start 5', 112, 22)}</td><td align="center">${btn('Iniciar 40x40', 'coliseum-tvt start 40', 112, 22)}</td></tr>`,
        `<tr><td align="center">${btn('Encerrar TvT', 'coliseum-tvt stop', 112, 24)}</td><td align="center">${btn('Ver Placar', 'coliseum-tvt scoreboard', 112, 24)}</td></tr>`,
        `</table>`
    ].join('');

    session.dataSendToMe(
        ServerResponse.npcHtml(session.actor.fetchId(), Html.page(body, { title: 'Coliseum TvT' }))
    );
}

function handleBypass(session, bypassInput) {
    const parts = Array.isArray(bypassInput)
        ? bypassInput.map((x) => String(x)).filter(Boolean)
        : String(bypassInput || '').replace(/^bypass\s+-h\s+/i, '').trim().split(/\s+/).filter(Boolean);

    if (parts[0] === 'coliseum-tvt') {
        parts.shift();
    }

    const sub = String(parts[0] || 'panel').toLowerCase();

    if (sub === 'start') {
        const parsedSize = Number(parts[1]);
        const teamArg = String(parts[2] || '').toUpperCase();
        const options = {};
        if (Number.isFinite(parsedSize) && parsedSize > 0) options.teamSize = parsedSize;
        if (teamArg === 'RED' || teamArg === 'BLUE') options.playerTeam = teamArg;
        const st = ColiseumTvtService.startMatch(session, options);
        sendNotice(session, `[Coliseum TvT] Iniciado (${st.counter}) | Duracao ${st.durationLabel} | Placar RED ${st.redKills} x ${st.blueKills} BLUE`);
        renderPanel(session, st);
        return true;
    }

    if (sub === 'scoreboard' || sub === 'rank' || sub === 'placar') {
        const pageNum = Number(parts[1] || 1) || 1;
        openScoreboard(session, null, pageNum);
        return true;
    }

    if (sub === 'stop' || sub === 'end') {
        const res = ColiseumTvtService.stopMatch('button', session?.actor || null);
        sendNotice(session, `[Coliseum TvT] Encerrado (${res.counter}) | ${res.winner || ''} | Placar final RED ${res.redKills} x ${res.blueKills} BLUE`);
        openScoreboard(session, res);
        return true;
    }

    renderPanel(session);
    return true;
}

handleBypass.render = renderPanel;
handleBypass.handleBypass = handleBypass;

module.exports = handleBypass;
