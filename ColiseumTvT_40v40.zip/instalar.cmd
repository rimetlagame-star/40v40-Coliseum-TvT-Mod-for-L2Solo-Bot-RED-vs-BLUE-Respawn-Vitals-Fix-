@echo off
chcp 65001 >nul
set "SCRIPT_DIR=%~dp0"
set "PS1_FILE=%SCRIPT_DIR%instalar.ps1"

if not exist "%PS1_FILE%" (
    echo [ERRO] instalar.ps1 nao encontrado em "%SCRIPT_DIR%".
    pause
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PS1_FILE%" %*
exit /b %ERRORLEVEL%
