param(
    [string]$GameServerPath = ""
)

$ErrorActionPreference = "Stop"
$ModDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallScript = Join-Path $ModDir "install.js"

Write-Host "====================================================" -ForegroundColor Cyan
Write-Host "   Instalador Coliseum TvT 40v40 (L2Solo)            " -ForegroundColor Cyan
Write-Host "====================================================" -ForegroundColor Cyan
Write-Host ""

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "[ERRO] Node.js nao foi encontrado no PATH." -ForegroundColor Red
    Write-Host "Instale o Node.js antes de continuar." -ForegroundColor Yellow
    Read-Host "Pressione ENTER para sair"
    exit 1
}

# Tenta detectar automaticamente se o instalador foi colado dentro da pasta do L2Solo (ou subpasta)
if ([string]::IsNullOrWhiteSpace($GameServerPath)) {
    $checkDir = $ModDir
    for ($i = 0; $i -lt 5; $i++) {
        if (Test-Path (Join-Path $checkDir "src\GameServer")) {
            $GameServerPath = $checkDir
            Write-Host "[AUTO] Pasta do L2Solo reconhecida automaticamente!" -ForegroundColor Green
            break
        }
        $parent = Split-Path -Parent $checkDir
        if ([string]::IsNullOrWhiteSpace($parent) -or $parent -eq $checkDir) { break }
        $checkDir = $parent
    }
}

# Se foi executado de fora (ex: pasta Meus mods), abre a janela para escolher a pasta
if ([string]::IsNullOrWhiteSpace($GameServerPath)) {
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = "Selecione a pasta raiz do seu projeto L2Solo (onde fica a pasta src)"
        $dialog.ShowNewFolderButton = $false
        $result = $dialog.ShowDialog()
        if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
            $GameServerPath = $dialog.SelectedPath
        }
    } catch {}
}

if ([string]::IsNullOrWhiteSpace($GameServerPath)) {
    $GameServerPath = Read-Host "Digite o caminho completo da pasta raiz do projeto L2Solo"
}

$GameServerPath = $GameServerPath.Trim('"').Trim()

if (-not (Test-Path (Join-Path $GameServerPath "src\GameServer"))) {
    Write-Host "[ERRO] Pasta L2Solo invalida: $GameServerPath" -ForegroundColor Red
    Write-Host "Certifique-se de que a pasta contem 'src\GameServer'." -ForegroundColor Yellow
    Read-Host "Pressione ENTER para sair"
    exit 1
}

Write-Host "Instalando em: $GameServerPath" -ForegroundColor Green
Write-Host ""

& node $InstallScript $GameServerPath

Write-Host ""
Write-Host "Instalacao concluida! Reinicie o GameServer e digite .tvt no jogo." -ForegroundColor Cyan
Read-Host "Pressione ENTER para fechar"
