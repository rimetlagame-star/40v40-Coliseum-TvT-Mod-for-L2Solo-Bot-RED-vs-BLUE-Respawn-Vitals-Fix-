const FailureLog = require('../../FailureLog');
const FaultHold = require('./BotFaultHold');
const ClassProgression = invoke('GameServer/ClassProgression');
const DiagnosticConfig = require('./Population/PopulationConfig');
const Speech = invoke('GameServer/Bot/AI/BotSpeechTemplates');
const { raiseDecision } = require('./AI/DecisionEvents');
const BotStatus      = invoke('GameServer/Bot/AI/BotStatus');
const BotRoles       = invoke('GameServer/Bot/AI/BotRoles');
const BotCombatUtility = invoke('GameServer/Bot/AI/BotCombatUtility');
const PartyArcherCombatPolicy = invoke('GameServer/Bot/AI/PartyArcherCombatPolicy');
const PopulationService = invoke('GameServer/Bot/Population/PopulationService');
const BotEquipmentUpgrade = invoke('GameServer/Bot/AI/BotEquipmentUpgrade');
const PartyCompanionService = invoke('GameServer/Bot/AI/PartyCompanionService');
const PartyRevivalService = invoke('GameServer/Bot/AI/PartyRevivalService');
const TownRespawn = invoke('GameServer/World/TownRespawn');
const Karma = invoke('GameServer/Karma');
const HotBotPolicyOverlay = invoke('GameServer/Bot/AI/HotBotPolicyOverlay');
const BotTradeService = invoke('GameServer/Bot/BotTradeService');
const ChatArrivalState = invoke('GameServer/Bot/AI/ChatArrivalState');
const BotRaidSafety = invoke('GameServer/Bot/AI/BotRaidSafety');
const HotActorLodPolicy = invoke('GameServer/Bot/AI/HotActorLodPolicy');
const HotAiDispatcher = invoke('GameServer/Bot/AI/HotAiDispatcher');
const SummonerTactics = invoke('GameServer/Bot/AI/SummonerTactics');
const SpoilSweep = invoke('GameServer/Npc/SpoilSweep');
const EffectRestrictions = invoke('GameServer/Effects/EffectRestrictions');
const BotRangedCombatPositioning = invoke('GameServer/Bot/AI/BotRangedCombatPositioning');
const HealingPotionStock = invoke('GameServer/Bot/AI/HealingPotionStock');
const SoloSelfHeal = invoke('GameServer/Bot/AI/SoloSelfHeal');
const BotClassPolicy = invoke('GameServer/Bot/AI/BotClassPolicy');
const { performance } = require('perf_hooks');
const ActorQueries = require('../World/ActorSpatialQueries');
const BotTownTravel = invoke('GameServer/Bot/AI/BotTownTravel');
const CompanionInventoryCleanup = require('./AI/CompanionInventoryCleanup');

// Visibility refreshes and damage can request an immediate AI pass from
// several nearby actors at once.  Without a small gate each request cancels
// and recreates the companion's normal timer, which can turn a group move
// into a tight synchronous AI loop.
const WAKEUP_THROTTLE_MS = 250;
const REAL_PLAYER_CACHE_MS = 250;
const SPOIL_SKILL_ID = 254;
const SWEEP_SKILL_ID = 42;
let realPlayerCache = { world: null, revision: -1, checkedAt: 0, sessions: [] };

function getRandomPhrase(category, ...args) {
    return Speech.line(`combat.${category}`, { target: args[0] });
}

function newbieSpawnCoords(classId) {
    const DataCache = invoke('GameServer/DataCache');
    return ClassProgression.firstClassRow(DataCache.newbieSpawns, classId, 'strict')?.spawns ?? [{ locX: -84318, locY: 244579, locZ: -3730 }];
}

function isRealPlayerSession(session) {
    return !!(
        session &&
        session.actor &&
        session.actor.fetchIsOnline() &&
        session.accountId &&
        !String(session.accountId).startsWith('bot_')
    );
}

function realPlayerSessions(World) {
    if (ActorQueries.native(World)) return ActorQueries.humans(World, isRealPlayerSession, true);
    const sessions = World?.user?.sessions;
    if (!Array.isArray(sessions)) return null;
    const timestamp = Date.now();
    const revision = Number(World.user.revision || 0);
    if (realPlayerCache.world === World && realPlayerCache.revision === revision && timestamp - realPlayerCache.checkedAt < REAL_PLAYER_CACHE_MS) {
        return realPlayerCache.sessions;
    }
    realPlayerCache = {
        world: World,
        revision,
        checkedAt: timestamp,
        sessions: sessions.filter(isRealPlayerSession)
    };
    return realPlayerCache.sessions;
}

const States = {
    fleeing: invoke('GameServer/Bot/AI/States/FleeingState'),
    pk_fleeing: invoke('GameServer/Bot/AI/States/PkFleeingState'),
    getting_buffed: invoke('GameServer/Bot/AI/States/GettingBuffedState'),
    resting: invoke('GameServer/Bot/AI/States/RestingState'),
    shopping: invoke('GameServer/Bot/AI/States/ShoppingState'),
    following: invoke('GameServer/Bot/AI/States/FollowingState'),
    hunting: invoke('GameServer/Bot/AI/States/HuntingState'),
    pk_hunting: invoke('GameServer/Bot/AI/States/PkHuntingState'),
    merchant: invoke('GameServer/Bot/AI/States/MerchantState')
};

function clearTacticalState(session) {
    invoke('GameServer/Bot/AI/BotPvpDefense').clear(session, { dead: true });
    session.currentTargetId = undefined;
    session.targetTrackId = undefined;
    session.targetAcquiredAt = undefined;
    session.targetLastDistance = undefined;
    session.targetStallTicks = 0;
    session.incomingThreatId = undefined;
    session.incomingThreatAt = undefined;
    session.roleDecision = undefined;
    session.lastDecision = undefined;
    session.lastTargetEvaluation = undefined;
    session.lastCombatDecision = undefined;
    session.lastPvpDecision = undefined;
    session.dangerMoment = undefined;
    session.retreatProgress = undefined;
    session.retreatFailure = undefined;
    session.spoilAttemptedTargetId = undefined;
    session.sweepAttemptedTargetId = undefined;
}

// The plan a bot falls back to: a player's companion follows, a merchant keeps its
// store, a player killer hunts players, any other bot hunts.
function ownPlan(session, bot) {
    if (session.followPlayerSession && session.partyCompanion === true) return 'following';
    if (session.plan === 'merchant' || bot.fetchPrivateStore?.()) return 'merchant';
    return session.pkProfile ? 'pk_hunting' : 'hunting';
}

// A hot AI state that threw: the cold step's answer (BotFaultHold). Counted under its plan
// (the first stack logged); the bot's state is held off longer per fault in a row while the
// rest of its tick (death, PvP defense, party sync) runs; at the fifth in a row it leaves
// that plan for its own (ownPlan), which runs at once, and its held decision is taken again,
// the step it held proved impossible (counted `ai.state_left`). A state tick that returns
// ends the run.
function stateFaulted(session, bot, plan, error, now = Date.now()) {
    FailureLog.note(`ai.state.${plan}`, error);
    const entry = session.stateFault ||= { count: 0, holdUntil: 0 };
    FaultHold.fault(entry, now);
    if (entry.count !== FaultHold.QUARANTINE_AFTER) return;
    FailureLog.note('ai.state_left', error);
    raiseDecision(session, 'goal_failed', { impossible: true });
    const own = ownPlan(session, bot);
    if (own === plan) return;
    bot.automation?.abortAll?.(bot);
    session.currentTargetId = undefined;
    session.plan = own;
    entry.holdUntil = now;
}

function recordHotStage(name, startedAt) {
    if (!DiagnosticConfig.developerDiagnostics) return;
    HotActorLodPolicy.recordSubsystem(name, performance.now() - startedAt, 1);
}

function targetIdOf(target) {
    return Number(target?.fetchId?.() || 0) || null;
}

function canPaySkill(actor, skill) {
    const cost = Math.max(0, Number(skill?.fetchConsumedMp?.() || 0));
    return Number(actor?.fetchMp?.() || 0) >= cost;
}

function targetIsDead(target) {
    return target?.isDead?.() === true || target?.state?.fetchDead?.() === true;
}

function trySpoil(session, bot, npc, Generics) {
    if (!session || !bot || !npc || !BotRoles.isSpoiler(bot) || targetIsDead(npc)) return false;
    if (npc.fetchAttackable?.() !== true) return false;

    const targetId = targetIdOf(npc);
    if (!targetId || session.spoilAttemptedTargetId === targetId) return false;

    const skill = bot.skillset?.fetchSkill?.(SPOIL_SKILL_ID);
    if (!skill || !canPaySkill(bot, skill) || bot.canUseSkill?.(skill) === false
        || typeof Generics?.skillExec !== 'function') return false;
    // Spoil lands on any monster, but one with no spoil list gives a bot nothing
    // for its MP. That lasts the whole encounter: no second look at the rewards.
    if (!SpoilSweep.hasSpoilList(npc)) {
        session.spoilAttemptedTargetId = targetId;
        return false;
    }

    // The attempt is encounter-scoped. Record it only after the transient
    // preflight gates pass, so a bot that recovers MP or leaves reuse can try
    // Spoil again before the same mob dies.
    session.spoilAttemptedTargetId = targetId;
    session.lastCombatDecision = {
        action: 'cast_spoil',
        role: 'spoiler',
        skillId: Number(skill.fetchSelfId?.() || SPOIL_SKILL_ID),
        skillName: skill.fetchName?.() || 'Spoil',
        targetId,
        at: Date.now()
    };
    Generics.skillExec(session, bot, { id: targetId, selfId: SPOIL_SKILL_ID, ctrl: true });
    return true;
}

function trySweep(session, bot, npc, Generics) {
    if (!session || !bot || !npc || !BotRoles.isSpoiler(bot) || !targetIsDead(npc)) return false;
    if (npc.fetchAttackable?.() !== true) return false;

    if (!SpoilSweep.isUnswept(npc)) return false;
    const spoilerId = SpoilSweep.spoilerId(npc);
    if (spoilerId && spoilerId !== targetIdOf(bot)) return false;

    const targetId = targetIdOf(npc);
    if (!targetId || session.sweepAttemptedTargetId === targetId) return false;
    if (bot.state?.fetchCasts?.()) return false;
    const skill = bot.skillset?.fetchSkill?.(SWEEP_SKILL_ID);
    if (!skill || !canPaySkill(bot, skill) || bot.canUseSkill?.(skill) === false
        || typeof Generics?.skillExec !== 'function') return false;

    session.sweepAttemptedTargetId = targetId;
    const pending = session.pendingSweeps?.get(targetId);
    if (pending) pending.retryAt = Date.now() + 750;
    session.lastCombatDecision = {
        action: 'cast_sweep',
        role: 'spoiler',
        skillId: Number(skill.fetchSelfId?.() || SWEEP_SKILL_ID),
        skillName: skill.fetchName?.() || 'Sweeper',
        targetId,
        at: Date.now()
    };
    Generics.skillExec(session, bot, { id: targetId, selfId: SWEEP_SKILL_ID, ctrl: true });
    return true;
}

const BotAI = {
    clearTacticalState,

    cancelScheduledTick(session) {
        if (!session) return false;
        session.aiScheduleGeneration = Number(session.aiScheduleGeneration || 0) + 1;
        if (session.aiTimeout) clearTimeout(session.aiTimeout);
        session.aiTimeout = null;
        return HotAiDispatcher.cancel(session);
    },

    scheduleTick(session, delayMs, { urgent = false } = {}) {
        if (!session?.actor || !session.aiActive || session.constActivityPaused) return false;
        this.cancelScheduledTick(session);
        const generation = Number(session.aiScheduleGeneration || 0);
        const runAiTick = () => {
            session.aiTimeout = null;
            if (!session.actor || !session.aiActive || Number(session.aiScheduleGeneration || 0) !== generation) return;
            HotAiDispatcher.enqueue(session, () => {
                if (!session.actor || !session.aiActive || Number(session.aiScheduleGeneration || 0) !== generation) return;
                try {
                    this.tick(session);
                } catch (err) {
                    console.error("Bot AI Tick Error:", err);
                }
                // A wakeup requested from inside the tick owns the next pass.
                if (!session.actor || !session.aiActive || Number(session.aiScheduleGeneration || 0) !== generation) return;
                this.scheduleTick(session, this.calculateNextTickDelay(session));
            }, {
                urgent,
                onError: (err) => console.error("Bot AI Dispatch Error:", err)
            });
        };
        session.aiTimeout = setTimeout(runAiTick, Math.max(0, Number(delayMs) || 0));
        return true;
    },

    init(session) {
        if (session.constActivityPaused) return;
        this.cancelScheduledTick(session);
        session.aiActive = true;
        // Once per activation: a later re-init must not bring back a servitor
        // that died near the player.
        if (session.coldSummon && session.actor) {
            invoke('GameServer/Npc/SummonControl').restoreFromCold(session, session.actor, session.coldSummon);
            session.coldSummon = null;
        }
        if (session.actor?.fetchClanId?.()) invoke('GameServer/Clan/ClanAllianceService').resume(session)
            .catch(error => utils.infoWarn('ClanQuest', 'resume failed: %s', error.message));
        this.scheduleTick(session, 1000 + Math.random() * 2000);
    },

    stop(session) {
        session.pendingShoppingMeeting?.controller.abort();
        invoke('GameServer/Bot/AI/TownNpcApproach').reset(session);
        invoke('GameServer/Bot/AI/TownTraffic').remove(Number(session.actor?.fetchId?.()));
        invoke('GameServer/Bot/AI/BotChatReactions').cancel(session);
        session.aiActive = false;
        session.pendingBrainTurns = [];
        session.pendingBrainTurn = null;
        HotBotPolicyOverlay.clearForCold(session);
        ChatArrivalState.clear(session, 'ai_stop');
        try { invoke('GameServer/Bot/AI/BotAmbientDirector').cleanup(session, 'ai_stop'); } catch (error) { FailureLog.note('ai.cleanup.ambient', error); }
        try { invoke('GameServer/Bot/AI/BotInferenceBudget').reset(session); } catch (error) { FailureLog.note('ai.cleanup.budget', error); }
        this.cancelScheduledTick(session);
    },

    wakeup(session, { urgent = false } = {}) {
        if (!session.actor || !session.aiActive) return;

        const now = Date.now();
        if (!urgent && now - Number(session.lastAiWakeAt || 0) < WAKEUP_THROTTLE_MS) return;
        session.lastAiWakeAt = now;

        // Even urgent damage/player-interaction reactions must leave the
        // network callback before AI work starts. The dispatcher prioritizes
        // them, coalesces duplicate wakes, and runs one actor per turn.
        this.scheduleTick(session, 0, { urgent });
    },

    calculateNextTickDelay(session) {
        const bot = session.actor;
        if (!bot) return 3000;
        const World = invoke('GameServer/World/World');
        const context = HotActorLodPolicy.evaluate(session, ActorQueries.native(World) ? World : realPlayerSessions(World) || []);
        const lodDelay = HotActorLodPolicy.nextTickDelay(session, context);
        return session.plan === 'shopping' && context.tier === 'full'
            ? Math.min(1500, lodDelay)
            : lodDelay;
    },

    promoteForPlayerInteraction(session, reason = 'player_interaction', sourceSession = null) {
        if (!session?.actor || !session.aiActive) return false;
        if (sourceSession && !HotActorLodPolicy.isRealPlayerSession(sourceSession)) return false;
        HotActorLodPolicy.promote(session, reason);
        this.wakeup(session, { urgent: true });
        return true;
    },

    getClosestTown(locX, locY, locZ) {
        const town = TownRespawn.getClosestTown(locX, locY, locZ);
        return { name: town.name, x: town.locX, y: town.locY, z: town.locZ };
    },

    getDeathRespawnTarget(session, bot, wasCompanion = false) {
        if (session?.pkProfile?.anchor) {
            return { ...session.pkProfile.anchor };
        }
        // With karma the PK point comes before the shop spot and the leader.
        if (Karma.closesTowns(bot.fetchKarma?.())) return TownRespawn.restartCoords(bot);

        if (session.plan === 'merchant' || (bot.fetchPrivateStore && bot.fetchPrivateStore())) {
            return {
                locX: session.initialSpawnCoord.locX,
                locY: session.initialSpawnCoord.locY,
                locZ: session.initialSpawnCoord.locZ
            };
        }

        const leader = session.followPlayerSession?.actor;
        if (wasCompanion && leader?.fetchIsOnline?.()) {
            return session.botStay && session.stayLocation ? {
                locX: session.stayLocation.locX,
                locY: session.stayLocation.locY,
                locZ: session.stayLocation.locZ
            } : {
                locX: leader.fetchLocX() + utils.oneFromSpan(-80, 80),
                locY: leader.fetchLocY() + utils.oneFromSpan(-80, 80),
                locZ: leader.fetchLocZ()
            };
        }

        return TownRespawn.restartCoords(bot);
    },

    beginPartyTownRecovery(session, bot, now = Date.now()) {
        const leaderSession = session.followPlayerSession;
        const role = BotRoles.inferRole(bot);
        const spawnTarget = this.getDeathRespawnTarget(session, bot, false);
        if (session.clanAllianceQuest) {
            // Resume the saved quest destination from town without queuing a
            // companion catch-up teleport that would interrupt the courier.
            session.plan = 'following';
            session.resumeAfterBuff = null;
            session.preBuffLocation = null;
            session.preBuffPlan = null;
            session.botStay = false;
            session.stayLocation = null;
            session.currentTargetId = undefined;
            return spawnTarget;
        }

        // Keep native party membership and the C4 party window intact. The
        // bot first restarts in town, refreshes Newbie Guide buffs when it is
        // eligible, then uses the same bounded catch-up teleport as a remotely
        // summoned const-party companion.
        session.preBuffLocation = { ...spawnTarget };
        session.preBuffPlan = 'following';
        session.resumeAfterBuff = {
            plan: 'following',
            followPlayerSession: leaderSession,
            partyCompanion: true,
            botStay: false,
            stayLocation: null,
            role,
            readyAt: now + 1500,
            conditionalNewbieBuff: true,
            waitForSafePartyReturn: true,
            returnMode: 'teleport',
            reason: 'party_town_respawn'
        };
        session.plan = 'getting_buffed';
        session.botStay = false;
        session.stayLocation = null;
        session.currentTargetId = undefined;
        session.roleDecision = {
            role,
            action: 'return_to_party',
            reason: 'town_respawn',
            at: now
        };
        return spawnTarget;
    },

    getClosestTownName(locX, locY, locZ) {
        return this.getClosestTown(locX, locY, locZ).name;
    },

    getClosestNewbieGuide(locX, locY) {
        return invoke('GameServer/Bot/AI/BotBuffs').closestGuide({ locX, locY });
    },

    triggerFarAwayChatEvent(session, bot) {
        return invoke('GameServer/Bot/Population/BotGlobalChat').maybeAmbient(session);
    },

    tick(session) {
        if (session.constActivityPaused) return;
        // Position changes only when TeleportTo completes. Damage wakeups in
        // that interval must not restart actions in the previous raid region.
        if (session.pendingActorTeleport || session.followPlayerSession?.pendingActorTeleport) return;
        invoke('GameServer/Bot/AI/BotClanChat').flush();
        invoke('GameServer/Bot/Economy/BotTradeChat').flush();
        const bot = session.actor;
        if (!bot) return;
        const tickStartedAt = Date.now();
        invoke('GameServer/Bot/AI/PendingSweep').prune(session, bot, tickStartedAt);
        let lodContext = { tier: 'preload' };

        try {

        // Supply errands are parked as a cold workflow while away from the
        // leader. No autonomous state, ambient event, or LLM pass may run
        // until the destination callback resumes the shopping phase.
        if (session.supplyErrandPhase === 'cold' || session.supplyErrandPhase === 'returning') return;

        const World = invoke('GameServer/World/World');
        const nativeActors = ActorQueries.native(World);
        lodContext = HotActorLodPolicy.evaluate(session, nativeActors ? World : realPlayerSessions(World) || [], tickStartedAt);
        PopulationService.recordHotTick(session);
        invoke('GameServer/Bot/Population/BotGlobalChat').offerReply(session, tickStartedAt);
        const botDead = bot.isDead();
        if (botDead) {
            clearTacticalState(session);
            HotBotPolicyOverlay.clearForDeath(session);
            BotTradeService.cleanup(session, 'death');
            invoke('GameServer/Bot/AI/TownNpcApproach').reset(session);
            invoke('GameServer/Bot/AI/TownTraffic').remove(Number(bot.fetchId()));
            try { invoke('GameServer/Bot/AI/BotAmbientDirector').cleanup(session, 'death'); } catch (error) { FailureLog.note('ai.cleanup.ambient', error); }
            if (session.clanAllianceQuest && invoke('GameServer/Clan/ClanAllianceService').recoverDeadCourier(session)) return;
        } else {
            // TTL expiry is intentionally lazy and bounded to hot ticks; no
            // background timer is needed for a session-local preference.
            HotBotPolicyOverlay.get(session);
        }
        // Actual player aggression owns the action window before travel,
        // conversation, recovery or ordinary party/PvE state routing.
        const defendingPvp = !botDead && invoke('GameServer/Bot/AI/BotPvpDefense').tick(session, bot, invoke(path.actor), this);
        if (!botDead && !defendingPvp && session.buffServiceCasting) return;
        if ((botDead || defendingPvp) && session.clanHallVisit) {
            invoke('GameServer/ClanHall/BotVisit').finish(session, bot);
        }

        // Accepted board custody owns travel and waiting before ordinary AI;
        // combat and death still release that hold and retain their priority.
        if (BotTownTravel.holdMeeting(session, bot, botDead || defendingPvp)) return;

        if (!botDead && !defendingPvp
            && invoke('GameServer/Bot/AI/ClanAllianceSupportAI').tick(session, bot, invoke(path.actor))) return;

        if (!botDead && !defendingPvp && session.clanAllianceQuest
            && invoke('GameServer/Bot/AI/ClanAllianceQuestAI').tick(session, bot, invoke(path.actor), this)) return;

        // A native trade remains open while the player edits and confirms the
        // offer. Do not let the ordinary town or hunting plan move the bot away.
        if (!botDead && !defendingPvp
            && BotTradeService.activeTradeSummary(session)) return;

        if (!botDead && !defendingPvp && (session.clanAmbitionActive || bot.fetchClanId?.())
            && invoke('GameServer/Bot/AI/ClanAmbitionQuestAI').tick(session, bot, invoke(path.actor), this)) return;

        if (!botDead && !defendingPvp) {
            const BuffServiceChat = invoke('GameServer/Bot/Economy/BuffServiceChat');
            if (BuffServiceChat.onDuty(session, tickStartedAt)) {
                BuffServiceChat.maybeAnnounce(session, tickStartedAt);
                return;
            }
        }

        if (lodContext.tier === 'preload' && !botDead && !defendingPvp) {
            if (Math.random() < 0.05) this.triggerFarAwayChatEvent(session, bot);
            return;
        }

        if (HotActorLodPolicy.shouldRefreshStatus(session, lodContext, tickStartedAt)) {
            const statusStartedAt = DiagnosticConfig.developerDiagnostics ? Date.now() : 0;
            session.botStatus = BotStatus.getStatus(session);
            HotActorLodPolicy.recordStatusRefresh(session, DiagnosticConfig.developerDiagnostics ? Date.now() - statusStartedAt : 0);
        }
        if (defendingPvp) {
            if (session.partyCompanion === true && session.followPlayerSession) PartyCompanionService.updateMember(session);
            return;
        }
        if (HotActorLodPolicy.budgetExceeded(lodContext, tickStartedAt)) {
            HotActorLodPolicy.recordDeferral();
            return;
        }
        // Autonomous state changes remain owned by the deterministic brain.
        // LLM inference is reserved for explicit player communication.

        // A cold bot explicitly asked to come is temporarily held near the
        // player. Keep this deterministic and independent from the LLM so the
        // normal hunting state cannot immediately overwrite the arrival.
        if (!botDead && ChatArrivalState.tick(session, bot)) {
            return;
        }

        // Its rebuff answered a buffer: it buys once, at a free moment (BuffService).
        if (!botDead && invoke('GameServer/Bot/Economy/BuffService').buyOnAnswer(session)) return;

        const isCompanion = !!session.followPlayerSession && session.partyCompanion === true;

        // Tiny chance to shout globally (e.g. 0.0005 chance per tick - roughly once every 2000 ticks or ~100 minutes per bot)
        if (Math.random() < 0.0005) {
            try {
                const BotManager = invoke('GameServer/Bot/BotManager');
                BotManager.handleBotGlobalShout(session);
            } catch (err) {
                console.error("Bot global shout error:", err);
            }
        }

        // If bot is a companion, dynamically refresh player's party HUD sidebar HP/MP bars
        if (isCompanion) {
            if (!botDead) CompanionInventoryCleanup.announceCapacity(session, bot);
            const partyMemberStartedAt = DiagnosticConfig.developerDiagnostics ? performance.now() : 0;
            PartyCompanionService.updateMember(session);
            recordHotStage('partyMemberSync', partyMemberStartedAt);
        }

        const Generics = invoke(path.actor);

        // 1. Handle Death State
        if (botDead) {
            const wasCompanion = session.partyCompanion === true && !!session.followPlayerSession;
            if (!session.deathTimerStart) {
                session.deathTimerStart = Date.now();
                if (session.tvtMatchId) {
                    const TvtService = invoke('GameServer/World/ColiseumTvtService');
                    const killer = bot.fetchLastAttacker?.() || bot.lastAttacker || null;
                    TvtService.recordKill(bot, killer);
                }
                if (session.hotBackgroundPartyId) {
                    invoke('GameServer/Bot/Population/HotPartyLifecycle')
                        .failRaidOnDeath(session, session.deathTimerStart)
                        .catch((error) => utils.infoWarn('RaidBoss', 'hot raid failure handling failed for %s: %s',
                            session.hotBackgroundPartyId, error?.message || error));
                }
                invoke('GameServer/Bot/AI/BotClanChat').onDeath(session, `hot:${session.deathTimerStart}`, session.deathTimerStart);
                if (wasCompanion) {
                    const deathReaction = PartyRevivalService.noteCompanionDeath(
                        session.followPlayerSession,
                        session,
                        session.deathTimerStart
                    );
                    invoke('GameServer/Bot/AI/BotPartyChat').announce(session, {
                        priority: 'critical',
                        key: `party-death:${bot.fetchId()}`,
                        templates: deathReaction.warning
                            ? [
                                `Down again. I'll wait for a safe resurrection, or restart and return if needed.`
                            ]
                            : [
                                `${bot.fetchName()} is down — waiting for resurrection.`,
                                `Down at the camp. Waiting for a resurrection.`
                            ]
                    });
                } else {
                    this.say(session, Speech.line('combat.death'), { ambient: true, key: 'death' });
                }
                if (wasCompanion && session.followPlayerSession?.actor?.isDead?.()) {
                    const BotSocialMemory = invoke('GameServer/Bot/AI/BotSocialMemory');
                    BotSocialMemory.recordEvent(session.followPlayerSession, session, 'party_wiped', 'bot_and_leader_dead');
                }
            }

            const ritualRescuePending = session.clanAllianceQuest
                && invoke('GameServer/Clan/ClanAllianceService').awaitingRitualResurrection(session);
            const rescueLeader = wasCompanion ? session.followPlayerSession
                : session.hotBackgroundPartyId ? invoke('GameServer/Bot/AI/HotBackgroundParty').partyLeader(session) : null;
            const hotParty = session.hotBackgroundPartyId
                ? invoke('GameServer/Bot/Population/BackgroundPartyState').find(session.hotBackgroundPartyId)
                : null;
            const failedBotClanRaid = hotParty?.stats?.raidEncounter?.status === 'failed';
            const partyRescuePending = !failedBotClanRaid && (ritualRescuePending
                || rescueLeader && !PartyRevivalService.shouldTownRespawn(rescueLeader, session));
            // Companions wait for the party's resurrection attempt.  The
            // normal town restart remains the escape hatch for a wipe, an
            // unsupported solo leader, or an unanswered corpse.
            if (!partyRescuePending && Date.now() - session.deathTimerStart > 12000) {
                const deathStartedAt = session.deathTimerStart;
                // TeleportTo rejects actors that are still marked dead, so bot
                // respawns must complete before applying the new town location.
                const hallRuntime = invoke('GameServer/ClanHall/Runtime');
                const recoveryHall = invoke('GameServer/ClanHall/BotVisit').restartHall(session, bot);
                Generics.revive(session, bot, { delayMs: 0,
                    restoreExpPercent: recoveryHall ? hallRuntime.expRestore(bot) : null,
                    recoveryReason: recoveryHall ? 'restart_to_clan_hall' : 'restart_to_town' });
                session.clanHallVisit = null;
                session.deathTimerStart = undefined;
                session.currentTargetId = undefined;
                session.incomingThreatId = undefined;
                session.incomingThreatAt = undefined;
                
                let spawnTarget;
                if (wasCompanion) {
                    invoke('GameServer/Bot/AI/BotPartyChat').announce(session, {
                        priority: 'critical',
                        key: `party-respawn-timeout:${bot.fetchId()}:${deathStartedAt}`,
                        templates: [
                            session.clanAllianceQuest
                                ? `No resurrection came. Restarting in town, then continuing my quest assignment.`
                                : `No resurrection came. Restarting in town, rebuffing if needed, then teleporting back.`
                        ]
                    });
                    // Keep the party relationship authoritative through the
                    // town restart. Population policy must also keep this
                    // visible recovery hot until the bot is back.
                    session.populationHotAt = Date.now();
                    session.noTargetTicks = 0;
                    spawnTarget = this.beginPartyTownRecovery(session, bot);
                } else if (bot.fetchKarma() > 0) {
                    session.plan = session.pkProfile ? 'pk_hunting' : 'hunting';
                    invoke('GameServer/Bot/AI/SpotService').leaveSpot(session);
                    session.noTargetTicks = 0;
                    spawnTarget = this.getDeathRespawnTarget(session, bot);
                } else if (session.plan === 'merchant' || (bot.fetchPrivateStore && bot.fetchPrivateStore())) {
                    session.plan = 'merchant';
                    bot.state.setSeated(true);
                    spawnTarget = {
                        locX: session.initialSpawnCoord.locX,
                        locY: session.initialSpawnCoord.locY,
                        locZ: session.initialSpawnCoord.locZ
                    };
                } else {
                    session.plan = 'hunting'; // Reset plan
                    // A hot party member keeps the spot it hunts on: the party tick brings it back from town.
                    if (!session.hotBackgroundPartyId) invoke('GameServer/Bot/AI/SpotService').leaveSpot(session);
                    session.noTargetTicks = 0;
                    spawnTarget = recoveryHall?.spawn || this.getDeathRespawnTarget(session, bot, false);
                }
                
                const tvtRespawnSvc = session.tvtMatchId ? invoke('GameServer/World/ColiseumTvtService') : null;
                if (tvtRespawnSvc) {
                    const tvtCoord = tvtRespawnSvc.getRespawnCoord?.(bot);
                    if (tvtCoord) {
                        spawnTarget = tvtCoord;
                    }
                }
                Generics.teleportTo(session, bot, spawnTarget);
                if (tvtRespawnSvc?.isTvTParticipant?.(bot)) {
                    tvtRespawnSvc.handleActorRespawn?.(session, bot);
                    if (typeof bot.fetchMaxHp === 'function' && typeof bot.setHp === 'function') {
                        bot.setHp(Number(bot.fetchMaxHp() || 0));
                    }
                    if (typeof bot.fetchMaxMp === 'function' && typeof bot.setMp === 'function') {
                        bot.setMp(Number(bot.fetchMaxMp() || 0));
                    }
                    if (typeof bot.fetchMaxCp === 'function' && typeof bot.setCp === 'function') {
                        bot.setCp(Number(bot.fetchMaxCp() || 0));
                    }
                    bot.fillupVitals?.();
                    bot.statusUpdateVitals?.(bot);
                }
                
                this.say(session, getRandomPhrase('revived'), { ambient: true, key: 'revived' });
            }
            return;
        }

        if (bot.state?.fetchDead?.()) {
            return;
        }

        // 2. Initialize default plan if not set
        if (!session.plan) {
            session.plan = 'hunting';
        }

        const equipmentStartedAt = DiagnosticConfig.developerDiagnostics ? performance.now() : 0;
        BotEquipmentUpgrade.applyBestUpgrades(session);
        recordHotStage('equipmentUpgrade', equipmentStartedAt);

        // Physical hot actors collect their ground drops before selecting the
        // next hunt or formation move. The queue yields to combat and support.
        if (isCompanion || session.hotBackgroundPartyId || session.partyGroundPickupQueue?.length
            || ['hunting', 'resting'].includes(session.plan)) {
            const groundLootStartedAt = DiagnosticConfig.developerDiagnostics ? performance.now() : 0;
            PartyCompanionService.reconcileGroundLoot(session);
            const startedGroundPickup = PartyCompanionService.startQueuedGroundPickup(session);
            recordHotStage('partyGroundLoot', groundLootStartedAt);
            if (startedGroundPickup) {
                return;
            }
        }

        // Reactions use the existing visible hot tick and never delay combat
        // or keep an actor seated just to finish a scripted exchange.
        if (lodContext.playerVisible) invoke('GameServer/Bot/AI/BotChatReactions').offerLocal(session, tickStartedAt);

        // 3. Dynamic State Machine Routing
        if (isCompanion) invoke('GameServer/Bot/AI/PlayerPartyRaidChatter').tick(session.followPlayerSession, tickStartedAt);
        if (!defendingPvp && invoke('GameServer/ClanHall/BotVisit').tick(session, bot)) return;
        if (invoke('GameServer/Bot/AI/HotResourceCompetition').tick(session)) return;
        if (session.hotBackgroundPartyId && invoke('GameServer/Bot/AI/HotBackgroundParty').tick(session, bot, Generics, this)) return;
        if (session.tvtMatchId) {
            const TvtService = invoke('GameServer/World/ColiseumTvtService');
            if (typeof bot.setKarma === 'function' && Number(bot.fetchKarma?.() || 0) !== 0) {
                bot.setKarma(0);
            }
            if (typeof bot.setPvpFlag === 'function' && Number(bot.fetchPvpFlag?.() || 0) !== 1) {
                bot.setPvpFlag(1);
            }
            const tvtEnemy = TvtService.findEnemyTarget(session, bot, 6000);
            const GenericsActor = invoke(path.actor);
            if (tvtEnemy) {
                const enemyId = Number(tvtEnemy.fetchId?.() || tvtEnemy.id || 0) || undefined;
                session.currentTargetId = enemyId;
                if (typeof bot.setTarget === 'function' && enemyId) {
                    try { bot.setTarget(enemyId); } catch (_) {}
                }
                const combatEngaged = this.executePvPCombat(session, bot, tvtEnemy, Generics, { pvp: true });
                const bx = Number(bot.fetchLocX?.() || 0);
                const by = Number(bot.fetchLocY?.() || 0);
                const bz = Number(bot.fetchLocZ?.() || TvtService.ARENA_CENTER.locZ);
                const tx = Number(tvtEnemy.fetchLocX?.() || bx);
                const ty = Number(tvtEnemy.fetchLocY?.() || by);
                const tz = Number(tvtEnemy.fetchLocZ?.() || bz);
                const dx = tx - bx;
                const dy = ty - by;
                const distSq = (dx * dx) + (dy * dy);
                const isMoving = Boolean(bot.state?.isMoving?.() || bot.moving || session.pendingPathRequest);
                if ((!combatEngaged || distSq > 220 * 220) && !isMoving && typeof GenericsActor?.moveTo === 'function') {
                    const clampedDest = typeof TvtService.clampToArena === 'function'
                        ? TvtService.clampToArena(tx, ty, tz)
                        : { locX: tx, locY: ty, locZ: tz };
                    GenericsActor.moveTo(session, bot, {
                        from: { locX: bx, locY: by, locZ: bz },
                        to: { locX: clampedDest.locX, locY: clampedDest.locY, locZ: clampedDest.locZ },
                        targetActor: tvtEnemy,
                        forceRepath: true
                    });
                }
            } else {
                session.currentTargetId = undefined;
                const center = TvtService.ARENA_CENTER;
                const isMoving = Boolean(bot.state?.isMoving?.() || bot.moving || session.pendingPathRequest);
                if (!isMoving && typeof GenericsActor?.moveTo === 'function') {
                    GenericsActor.moveTo(session, bot, {
                        from: { locX: Number(bot.fetchLocX?.() || center.locX), locY: Number(bot.fetchLocY?.() || center.locY), locZ: Number(bot.fetchLocZ?.() || center.locZ) },
                        to: { locX: center.locX, locY: center.locY, locZ: center.locZ },
                        forceRepath: true
                    });
                }
            }
            return;
        }
        const state = States[session.plan];
        if (!['resting', 'shopping'].includes(session.plan)) {
            invoke('GameServer/AfkTrade/TradeMeetingService').breakChanged(session, 0);
        }
        if (state) {
            const stateName = session.plan;
            const stateStartedAt = DiagnosticConfig.developerDiagnostics ? performance.now() : 0;
            // A state held off after its faults (stateFaulted) waits.
            if (session.stateFault?.holdUntil > tickStartedAt) return;
            try {
                state.tick(session, bot, Generics, BotAI);
                if (session.stateFault) session.stateFault = null;
            } catch (err) {
                stateFaulted(session, bot, stateName, err);
            } finally {
                DiagnosticConfig.developerDiagnostics && recordHotStage(`state.${stateName}`, stateStartedAt);
            }
        } else {
            utils.infoWarn('GameServer', 'Unhandled Bot plan: %s', session.plan);
        }
        } finally {
            if (DiagnosticConfig.developerDiagnostics) HotActorLodPolicy.recordTick(lodContext.tier, Date.now() - tickStartedAt);
        }
    },

    executePvPCombat(session, bot, victim, Generics, options = {}) {
        return this.executeCombat(session, bot, victim, Generics, { ...options, pvp: true });
    },

    executeCombat(session, bot, npc, Generics, options = {}) {
        if (npc && session?.partyCompanion
            && invoke('GameServer/Bot/AI/PartyAwareness').isCombatAlly(session.followPlayerSession, npc)) {
            invoke('GameServer/Bot/AI/BotPvpTactics').stop(session, bot);
            session.currentTargetId = undefined;
            return false;
        }
        if (npc && !invoke('GameServer/Bot/AI/ClanCommandParty').canAttack(session, npc)) return false;
        const Casts = invoke('GameServer/Bot/AI/HotPartyCastTracker');
        const scope = Casts.scopeFor(session);
        if (npc && scope && Casts.protectedControl(scope, npc)) {
            invoke('GameServer/Bot/AI/BotPvpTactics').stop(session, bot);
            session.currentTargetId = undefined;
            return false;
        }
        if (!npc) {
            if (session) session.lastCombatDecision = { action: 'blocked', reason: 'target_dead_or_missing', at: Date.now() };
            return false;
        }
        const allowedPlayerPartyRaid = BotRaidSafety.isProtectedRaidEntity(npc) &&
            BotRaidSafety.canEngagePlayerPartyRaid(session, npc, options.playerPartyRaidLeaderSession);
        const allowedBotClanRaid = BotRaidSafety.isProtectedRaidEntity(npc)
            && BotRaidSafety.canEngageBotClanRaid(session, npc);
        if (BotRaidSafety.isProtectedRaidEntity(npc) && !allowedPlayerPartyRaid && !allowedBotClanRaid) {
            BotRaidSafety.clearTarget(session, bot, npc);
            if (session) {
                session.lastCombatDecision = {
                    action: 'blocked',
                    reason: 'raid_entity_protected',
                    targetId: Number(npc?.fetchId?.() || 0) || null,
                    at: Date.now()
                };
            }
            return false;
        }
        const canCast = EffectRestrictions.canCast(bot);
        const canAttack = EffectRestrictions.canAttack(bot);
        // Stun, sleep, fear, and paralyze disable every action. Stop before
        // ranged positioning as well: internal hot-bot movement and combat
        // calls do not pass through the player's packet-level effect gates.
        if (!EffectRestrictions.canUseBasicAction(bot)) {
            if (session) {
                session.lastCombatDecision = {
                    action: 'blocked',
                    reason: 'control_effect',
                    targetId: Number(npc?.fetchId?.() || 0) || null,
                    at: Date.now()
                };
            }
            return false;
        }
        if (!options.pvp && invoke('GameServer/Bot/AI/HotResourceCompetition').beforeAttack(session, npc)) return false;
        if (options.emergencyFinisher && !options.pvp) {
            const finish = invoke('GameServer/Bot/AI/BotEmergencyFinisher').evaluate(session, bot, npc);
            if (!finish) return false;
            session.lastCombatDecision = { ...finish, reason: 'safe_emergency_finisher', at: Date.now() };
            if (finish.action === 'cast_skill') {
                Generics.skillExec(session, bot, { id: npc.fetchId(), selfId: finish.skillId, ctrl: true });
            } else {
                Generics.attackExec(session, bot, { id: npc.fetchId(), ctrl: true });
            }
            return true;
        }
        const role = BotRoles.combatRoleFor(bot);
        const conserveArcherSkills = PartyArcherCombatPolicy.conserveSkills(session, bot, npc, { ...options, role });
        const basicAttackOnly = options.basicAttackOnly || conserveArcherSkills;
        // A potion is a survival action for a fight already in progress, not
        // routine topping-off. The policy also blocks repeats for the same
        // target and while a previous potion HoT remains active.
        if (HealingPotionStock.tryUseInCombat(session, bot, npc, { role, pvp: options.pvp === true })) {
            return true;
        }
        // A solo bot on mobs heals itself by the rule hot and cold share.
        if (!options.pvp && BotClassPolicy.modeFor(bot, { session }) === 'solo_pve'
            && SoloSelfHeal.tryInFight(session, bot, npc, Generics)) {
            return true;
        }
        if (!basicAttackOnly && trySpoil(session, bot, npc, Generics)) {
            return true;
        }
        if (BotRangedCombatPositioning.reposition(session, bot, npc, { role })) {
            return true;
        }
        const BOW_ATTACK_RANGE = 700;
        const hasBow = bot?.backpack?.fetchTotalWeaponKind?.() === 'Weapon.Bow';
        const casterWeaponCombat = BotRoles.usesCasterWeaponCombat(bot);
        const mageMeleeFinish = casterWeaponCombat && canAttack
            ? BotCombatUtility.mageMeleeFinishOpportunity(bot, npc)
            : null;
        if (mageMeleeFinish) {
            session.lastCombatDecision = {
                action: 'basic_attack',
                role,
                reason: 'mage_melee_finisher',
                targetId: Number(npc?.fetchId?.() || 0) || null,
                targetHp: mageMeleeFinish.targetHp,
                estimatedDamage: mageMeleeFinish.damagePerHit,
                estimatedHits: mageMeleeFinish.estimatedHits,
                at: Date.now()
            };
            Generics.attackExec(session, bot, {
                id: npc.fetchId(),
                ctrl: true
            });
            return true;
        }
        // Support controllers may reserve MP instead of casting offensively.
        // Staff casters may then assist only with a cheap melee finisher;
        // melee support classes retain their normal weapon fallback.
        const combatPolicy = {
            ...HotBotPolicyOverlay.combatPolicy(session),
            ...(typeof options.party === 'boolean' ? { party: options.party } : {}),
            pvp: options.pvp === true,
            avoidAreaDamage: options.avoidAreaDamage === true || (
                (allowedPlayerPartyRaid || allowedBotClanRaid) && BotRaidSafety.hasControlledRaidMinion(npc)
            )
        };
        // Bot casts use the internal SkillExec path and therefore do not pass
        // through the packet-level SkillRequest control-effect gate.
        const summonAction = basicAttackOnly || !canCast
            ? null
            : SummonerTactics.combatAction(session, bot, npc, Generics);
        if (summonAction?.handled) {
            session.lastCombatDecision = {
                action: summonAction.reason,
                role,
                skillId: summonAction.skill?.fetchSelfId?.() || null,
                targetId: summonAction.target?.fetchId?.() || npc?.fetchId?.() || null,
                at: Date.now()
            };
            return true;
        }
        // Necromancers may still use the corpse through SummonerTactics above.
        // Damage and charge preparation must not restart against that corpse.
        if (npc.isDead?.() === true || npc.state?.fetchDead?.() === true || npc.fetchHp?.() <= 0) {
            session.lastCombatDecision = { action: 'blocked', reason: 'target_dead_or_missing', at: Date.now() };
            return false;
        }
        const selfTactic = basicAttackOnly || !canCast ? null
            : invoke('GameServer/Bot/AI/PartyClassTactics').selfAction(bot, {
                role,
                activeMobs: Number(options.activeMobs ?? 1),
                target: npc,
                raidBoss: allowedBotClanRaid || allowedPlayerPartyRaid
            });
        if (selfTactic) {
            session.lastCombatDecision = { action:'self_support', role, reason:selfTactic.reason,
                skillId:selfTactic.skill.fetchSelfId(), targetId:bot.fetchId(), at:Date.now() };
            Generics.skillExec(session,bot,{id:bot.fetchId(),selfId:selfTactic.skill.fetchSelfId(),ctrl:true});
            return true;
        }
        combatPolicy.rejectedAlternatives = [];
        // One offensive select per call: the charge plan competes with it and
        // the cast below uses it when no charge is prepared.
        const offense = basicAttackOnly || !canCast ? null
            : BotCombatUtility.selectAttackAndChargePlan(bot, npc, role, combatPolicy);
        const chargePlan = offense?.charge;
        const chargeSkill = chargePlan?.skill;
        if (chargeSkill) {
            session.lastCombatDecision = {
                action: 'charge_skill',
                role,
                skillId: chargeSkill.fetchSelfId(),
                skillName: chargeSkill.fetchName?.() || null,
                plannedSkillId: chargePlan.spender.fetchSelfId(),
                requiredCharges: chargePlan.requiredCharges,
                castsRemaining: chargePlan.castsRemaining,
                reason: chargePlan.reason,
                charges: Number(bot.fetchCharges?.() ?? bot.charges ?? 0) || 0,
                at: Date.now()
            };
            Generics.skillExec(session, bot, {
                id: bot.fetchId(),
                selfId: chargeSkill.fetchSelfId(),
                ctrl: true
            });
            return true;
        }
        const decision = offense?.ready || null;
        // The pet tanks a solo fight: the chosen hit waits on its hate (PetTankRule).
        if (SummonerTactics.ownerWaits(session, bot, npc, summonAction, decision?.skill)) {
            session.lastCombatDecision = { action: 'summon_tanks', role, targetId: npc.fetchId(), at: Date.now() };
            return true;
        }
        if (decision && !Casts.mayCast(session, npc, decision.skill)) {
            session.lastCombatDecision = { action: 'blocked', reason: 'party_cast_reserved', targetId: npc.fetchId(), at: Date.now() };
            return false;
        }
        if (decision) {
            session.lastCombatDecision = {
                action: 'cast_skill',
                role,
                skillId: decision.skill.fetchSelfId(),
                skillName: decision.skill.fetchName?.() || null,
                score: decision.score,
                reasons: decision.reasons,
                intent: decision.intent,
                targetId: npc.fetchId(),
                resourceCost: { mp: decision.cost, hp: Number(decision.skill.fetchConsumedHp?.() || 0) },
                rejectedAlternatives: combatPolicy.rejectedAlternatives,
                at: Date.now()
            };
            Generics.skillExec(session, bot, {
                id: npc.fetchId(),
                selfId: decision.skill.fetchSelfId(),
                ctrl: true
            });
            return true;
        }

        // Physical mute may still allow a spell, but must never fall through
        // to the direct attackExec path when no spell was selected.
        if (!canAttack) {
            session.lastCombatDecision = {
                action: 'blocked',
                role,
                reason: 'physical_attack_disabled',
                targetId: Number(npc?.fetchId?.() || 0) || null,
                at: Date.now()
            };
            return false;
        }

        // A hot staff caster may use its weapon only as a cheap finisher. If the
        // target cannot be killed in roughly two ordinary hits, waiting for
        // mana or letting the rest of the party continue is preferable to
        // turning the caster into a melee fighter.
        if (casterWeaponCombat && options.pvp !== true) {
            session.lastCombatDecision = {
                action: 'blocked',
                role,
                reason: 'mage_melee_reserved_for_finisher',
                targetId: Number(npc?.fetchId?.() || 0) || null,
                at: Date.now()
            };
            return false;
        }

        session.lastCombatDecision = {
            action: 'basic_attack',
            role,
            reason: conserveArcherSkills ? 'party_archer_conserve_skills' : 'no_usable_offensive_skill',
            rejectedAlternatives: combatPolicy.rejectedAlternatives || [],
            at: Date.now()
        };
        Generics.attackExec(session, bot, {
            id: npc.fetchId(),
            ctrl: true,
            ...(hasBow ? { range: BOW_ATTACK_RANGE } : {})
        });
        return true;
    },

    say(session, text, chatter = null) {
        if (chatter?.ambient) {
            const budget = invoke('GameServer/Bot/AI/BotChatterBudget');
            const reactions = invoke('GameServer/Bot/AI/BotChatReactions');
            if (session.inConversation || reactions.isBusy(session) || !budget.canSend(session, chatter.key)) return false;
            const voice = invoke('GameServer/Bot/AI/BotChatVoice');
            invoke('GameServer/Bot/BotManager').botSay(session, voice.line(`local.${chatter.key}`, session) || text);
            budget.record(session, chatter.key);
            reactions.openLocal(session, chatter.key);
            return true;
        }
        return invoke('GameServer/Bot/BotManager').botSay(session, text);
    },

    tell(session, targetSession, text, delivery = {}) {
        invoke('GameServer/Bot/BotManager').botTell(session, targetSession, text, delivery);
    },

    trade(session, text) {
        if (!session.actor) return;
        const ServerResponse = invoke('GameServer/Network/Response');
        const World = invoke('GameServer/World/World');
        const packet = ServerResponse.speak(session.actor, { kind: 8, text: text });

        ActorQueries.humans(World).forEach((user) => {
            if (user.socket && typeof user.socket.write === 'function' && user.accountId.indexOf('bot_') !== 0) {
                user.dataSendToMe(packet);
            }
        });
    },

    getStatus(session) {
        const status = BotStatus.getStatus(session);
        session.botStatus = status;
        return status;
    },

    summarizeStatus(session) {
        return BotStatus.summarize(this.getStatus(session));
    },

    trySweep(session, bot, npc, Generics) {
        return trySweep(session, bot, npc, Generics);
    }
};

BotAI.getRandomPhrase = getRandomPhrase;
BotAI.newbieSpawnCoords = newbieSpawnCoords;

module.exports = BotAI;
