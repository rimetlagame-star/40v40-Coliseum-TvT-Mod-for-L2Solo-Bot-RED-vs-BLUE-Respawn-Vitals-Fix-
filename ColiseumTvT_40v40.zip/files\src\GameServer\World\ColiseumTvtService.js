const GeodataEngine = invoke('GameServer/Geodata/GeodataEngine');
const ShotStock = invoke('GameServer/Inventory/ShotStock');
const World = invoke('GameServer/World/World');
const ServerResponse = invoke('GameServer/Network/Response');

const ARENA_CENTER = Object.freeze({
    locX: 149500,
    locY: 46720,
    locZ: -3413
});

const BOUNDS = Object.freeze({
    minX: 147750,
    maxX: 151250,
    minY: 45650,
    maxY: 47750,
    minZ: -3600,
    maxZ: -3200
});

const TEAM_BASES = Object.freeze({
    RED: Object.freeze({
        name: 'RED',
        locX: 148300,
        locY: 46720,
        locZ: -3413,
        heading: 0
    }),
    BLUE: Object.freeze({
        name: 'BLUE',
        locX: 150700,
        locY: 46720,
        locZ: -3413,
        heading: 32768
    })
});

const MAX_PER_TEAM = 40;
const DEFAULT_TEAM_SIZE = 5;
const DEFAULT_DURATION_MS = 5 * 60 * 1000;

let activeMatch = null;
let matchCounter = 0;
let matchTickInterval = null;

function formatClock(ms) {
    const totalSec = Math.max(0, Math.ceil(Number(ms || 0) / 1000));
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function formatRemainingHuman(remainingSec) {
    const sec = Math.max(0, Math.ceil(remainingSec));
    if (sec >= 60) {
        const mins = Math.round(sec / 60);
        return `${mins} ${mins === 1 ? 'minuto' : 'minutos'}`;
    }
    return `${sec} ${sec === 1 ? 'segundo' : 'segundos'}`;
}

function broadcastGlobalShout(text, senderActor = null) {
    const message = String(text || '').trim();
    if (!message) return;
    const speaker = senderActor || activeMatch?.teams?.RED?.[0]?.actor || activeMatch?.teams?.BLUE?.[0]?.actor || null;
    if (!speaker || typeof ServerResponse?.speak !== 'function') return;

    const packet = ServerResponse.speak(speaker, {
        kind: 1,
        name: 'ColiseumTvT',
        text: message
    });

    const sessions = World?.user?.sessions;
    if (!sessions || typeof sessions.forEach !== 'function') return;

    sessions.forEach((user) => {
        if (user?.socket && typeof user.socket.write === 'function' && String(user.accountId || '').indexOf('bot_') !== 0) {
            user.dataSendToMe?.(packet);
        }
    });
}

function enforceActiveMatchFlags(match) {
    if (!match || !match.participantsByActorId) return;
    for (const entry of match.participantsByActorId.values()) {
        const actor = entry?.actor;
        const session = entry?.session || actor?.session;
        if (!actor) continue;
        if (session?.pvpFlagTimer) {
            clearTimeout(session.pvpFlagTimer);
            session.pvpFlagTimer = undefined;
        }
        if (typeof actor.setKarma === 'function' && Number(actor.fetchKarma?.() || 0) !== 0) {
            actor.setKarma(0);
        }
        if (typeof actor.setPvpFlag === 'function' && Number(actor.fetchPvpFlag?.() || 0) !== 1) {
            actor.setPvpFlag(1);
            if (session && typeof session.dataSendToMe === 'function' && typeof ServerResponse?.userInfo === 'function') {
                session.dataSendToMe(ServerResponse.userInfo(actor));
            }
            if (session && typeof session.dataSendToOthers === 'function') {
                if (typeof ServerResponse?.charInfo === 'function') {
                    session.dataSendToOthers(ServerResponse.charInfo(actor), actor);
                }
                if (typeof ServerResponse?.relationChanged === 'function') {
                    session.dataSendToOthers(ServerResponse.relationChanged(actor), actor);
                }
            }
        }
    }
}

function clearMatchTimer() {
    if (matchTickInterval) {
        clearInterval(matchTickInterval);
        matchTickInterval = null;
    }
}

function actorIdOf(actor) {
    return Number(actor?.fetchId?.() || actor?.id || 0) || null;
}

function actorNameOf(actor) {
    return String(actor?.fetchName?.() || actor?.name || 'Unknown');
}

function isActorDead(actor) {
    return !actor || actor.isDead?.() === true || actor.state?.fetchDead?.() === true;
}

function isMerchantSession(session) {
    const storeType = Number(session?.actor?.getPrivateStoreType?.() || 0);
    return session?.plan === 'merchant'
        || storeType > 0
        || Boolean(session?.actor?.privateStore)
        || Boolean(session?.manufactureShop);
}

function syncActorVisuals(session, actor) {
    if (!actor) return;
    if (typeof actor.setKarma === 'function' && Number(actor.fetchKarma?.() || 0) !== 0) {
        actor.setKarma(0);
    }
    if (typeof actor.setPvpFlag === 'function' && Number(actor.fetchPvpFlag?.() || 0) !== 1) {
        actor.setPvpFlag(1);
    }
    if (session?.pvpFlagTimer) {
        clearTimeout(session.pvpFlagTimer);
        session.pvpFlagTimer = undefined;
    }
    if (session && typeof session.dataSendToMe === 'function' && typeof ServerResponse?.userInfo === 'function') {
        session.dataSendToMe(ServerResponse.userInfo(actor));
    }
    if (session && typeof session.dataSendToOthers === 'function') {
        if (typeof ServerResponse?.charInfo === 'function') {
            session.dataSendToOthers(ServerResponse.charInfo(actor), actor);
        }
        if (typeof ServerResponse?.relationChanged === 'function') {
            session.dataSendToOthers(ServerResponse.relationChanged(actor), actor);
        }
    }
}

function applyTeamTitleAndNoPk(session, actor, team) {
    if (!actor) return;
    if (typeof actor.setTitle === 'function') {
        actor.setTitle(team);
    }
    syncActorVisuals(session, actor);
}

function computeSlotCoord(team, slotIndex) {
    const base = TEAM_BASES[team] || TEAM_BASES.RED;
    const cols = 4;
    const spacingX = 55;
    const spacingY = 55;
    const col = slotIndex % cols;
    const row = Math.floor(slotIndex / cols);
    const dirX = team === 'RED' ? -1 : 1;

    const rawX = base.locX + (col * spacingX * dirX);
    const rawY = base.locY + ((row - 4.5) * spacingY);
    const clampedX = Math.max(BOUNDS.minX + 120, Math.min(BOUNDS.maxX - 120, rawX));
    const clampedY = Math.max(BOUNDS.minY + 120, Math.min(BOUNDS.maxY - 120, rawY));
    const locZ = GeodataEngine.getHeight(clampedX, clampedY, base.locZ);

    return {
        locX: Math.round(clampedX),
        locY: Math.round(clampedY),
        locZ: Math.round(locZ),
        heading: base.heading
    };
}

function prepareCombatantActor(session, actor, coord, team = null) {
    if (!actor) return;
    actor.state?.setDead?.(false);
    actor.state?.setSeated?.(false);
    actor.automation?.stopReplenish?.();
    if (typeof actor.setKarma === 'function') {
        actor.setKarma(0);
    }
    if (typeof actor.setPvpFlag === 'function') {
        actor.setPvpFlag(1);
    }
    if (session?.pvpFlagTimer) {
        clearTimeout(session.pvpFlagTimer);
        session.pvpFlagTimer = undefined;
    }
    if (team && typeof actor.setTitle === 'function') {
        actor.setTitle(team);
    }
    if (coord && typeof coord.heading === 'number' && typeof actor.setHeading === 'function') {
        actor.setHeading(coord.heading);
    }
    if (session?.accountId && String(session.accountId).startsWith('bot_')) {
        ShotStock?.enableAutoShot?.(actor);
    }
    if (typeof actor.fetchMaxHp === 'function' && typeof actor.setHp === 'function') {
        actor.setHp(Number(actor.fetchMaxHp() || 0));
    }
    if (typeof actor.fetchMaxMp === 'function' && typeof actor.setMp === 'function') {
        actor.setMp(Number(actor.fetchMaxMp() || 0));
    }
    if (typeof actor.fetchMaxCp === 'function' && typeof actor.setCp === 'function') {
        actor.setCp(Number(actor.fetchMaxCp() || 0));
    }
    actor.fillupVitals?.();
    actor.statusUpdateVitals?.(actor);
    syncActorVisuals(session, actor);
}

function teleportToCoord(session, actor, coord) {
    if (!actor || !coord) return;
    const Generics = invoke(path.actor);
    if (typeof Generics?.teleportTo === 'function') {
        Generics.teleportTo(session, actor, coord);
        return;
    }
    if (typeof actor.teleToLocation === 'function') {
        actor.teleToLocation(coord.locX, coord.locY, coord.locZ, true);
    } else if (typeof actor.setLoc === 'function') {
        actor.setLoc(coord.locX, coord.locY, coord.locZ);
    }
    if (session) {
        World.updateUserLocation(session, actor);
    }
}

function snapshotSession(session, isBot) {
    const actor = session?.actor;
    return {
        isBot,
        locX: Number(actor?.fetchLocX?.() ?? session?.initialSpawnCoord?.locX ?? ARENA_CENTER.locX),
        locY: Number(actor?.fetchLocY?.() ?? session?.initialSpawnCoord?.locY ?? ARENA_CENTER.locY),
        locZ: Number(actor?.fetchLocZ?.() ?? session?.initialSpawnCoord?.locZ ?? ARENA_CENTER.locZ),
        title: typeof actor?.fetchTitle === 'function' ? String(actor.fetchTitle() ?? '') : '',
        karma: typeof actor?.fetchKarma === 'function' ? Number(actor.fetchKarma() || 0) : 0,
        plan: session?.plan,
        currentSpot: session?.currentSpot || null,
        spotRelocation: session?.spotRelocation ? { ...session.spotRelocation } : null,
        populationLocationPolicy: session?.populationLocationPolicy || 'return'
    };
}

function restoreFullVitals(session, actor) {
    if (!actor) return;
    if (session) {
        try { invoke(path.actor)?.calculateStats?.refresh?.(session, actor); } catch (_) {}
    }
    if (typeof actor.fetchMaxHp === 'function' && typeof actor.setHp === 'function') {
        actor.setHp(Number(actor.fetchMaxHp() || 0));
    }
    if (typeof actor.fetchMaxMp === 'function' && typeof actor.setMp === 'function') {
        actor.setMp(Number(actor.fetchMaxMp() || 0));
    }
    if (typeof actor.fetchMaxCp === 'function' && typeof actor.setCp === 'function') {
        actor.setCp(Number(actor.fetchMaxCp() || 0));
    }
    actor.fillupVitals?.();
    if (typeof actor.fetchMaxHp === 'function' && typeof actor.setHp === 'function') {
        actor.setHp(Number(actor.fetchMaxHp() || 0));
    }
    if (typeof actor.fetchMaxMp === 'function' && typeof actor.setMp === 'function') {
        actor.setMp(Number(actor.fetchMaxMp() || 0));
    }
    if (typeof actor.fetchMaxCp === 'function' && typeof actor.setCp === 'function') {
        actor.setCp(Number(actor.fetchMaxCp() || 0));
    }
    actor.statusUpdateVitals?.(actor);
}

function applyTvtEventBuffs(session, actor, entry = null) {
    if (!actor) return;
    const FullBuff = invoke('GameServer/World/Generics/NpcBypasses/AdminFullBuff');
    if (typeof FullBuff?.applyFullBuff !== 'function') return;
    try {
        const res = FullBuff.applyFullBuff(session || null, actor, { expiresAt: Date.now() + 30 * 60 * 1000 });
        if (entry) {
            if (!entry.tvtBuffKeys) entry.tvtBuffKeys = new Set();
            if (!entry.tvtSummonBuffKeys) entry.tvtSummonBuffKeys = new Set();
            for (const eff of (res?.applied || [])) {
                if (eff?.key) entry.tvtBuffKeys.add(eff.key);
            }
            for (const eff of (res?.summonApplied || [])) {
                if (eff?.key) entry.tvtSummonBuffKeys.add(eff.key);
            }
        }
        restoreFullVitals(session, actor);
    } catch (err) {
        utils.infoWarn('ColiseumTvT', 'falha ao aplicar buff do evento: %s', err?.message || err);
    }
}

function clearTvtEventBuffs(entry) {
    const { session, actor } = entry || {};
    if (!actor) return;
    const EffectStore = invoke('GameServer/Effects/EffectStore');
    const keys = entry?.tvtBuffKeys ? Array.from(entry.tvtBuffKeys) : [];
    if (keys.length && typeof EffectStore?.remove === 'function') {
        for (const k of keys) {
            try { EffectStore.remove(actor, k); } catch (_) {}
            if (actor.activeBuffs && Object.prototype.hasOwnProperty.call(actor.activeBuffs, k)) {
                delete actor.activeBuffs[k];
            }
        }
    }
    if (entry?.tvtBuffKeys) entry.tvtBuffKeys.clear();

    try {
        const AdminFullBuff = invoke('GameServer/World/Generics/NpcBypasses/AdminFullBuff');
        const summon = AdminFullBuff ? invoke('GameServer/Effects/EffectStore') : null;
        const sKeys = entry?.tvtSummonBuffKeys ? Array.from(entry.tvtSummonBuffKeys) : [];
        if (sKeys.length && typeof EffectStore?.remove === 'function') {
            const summonActor = actor.summon || actor.pet || null;
            if (summonActor) {
                for (const sk of sKeys) {
                    try { EffectStore.remove(summonActor, sk); } catch (_) {}
                    if (summonActor.activeBuffs && Object.prototype.hasOwnProperty.call(summonActor.activeBuffs, sk)) {
                        delete summonActor.activeBuffs[sk];
                    }
                }
                if (session && typeof AdminFullBuff?.refreshSummon === 'function') {
                    AdminFullBuff.refreshSummon(session, summonActor);
                }
            }
        }
        if (entry?.tvtSummonBuffKeys) entry.tvtSummonBuffKeys.clear();
        const Generics = invoke(path.actor);
        Generics?.calculateStats?.(session || null, actor);
        actor.statusUpdateVitals?.(actor);
        if (session && typeof session.dataSendToMe === 'function') {
            if (typeof ServerResponse?.userInfo === 'function') session.dataSendToMe(ServerResponse.userInfo(actor));
            if (typeof ServerResponse?.abnormalStatusUpdate?.fromActor === 'function') session.dataSendToMe(ServerResponse.abnormalStatusUpdate.fromActor(actor));
            if (typeof ServerResponse?.shortBuffStatusUpdate?.fromActor === 'function') session.dataSendToMe(ServerResponse.shortBuffStatusUpdate.fromActor(actor));
        }
    } catch (err) {
        utils.infoWarn('ColiseumTvT', 'falha ao remover buff do evento: %s', err?.message || err);
    }
}

function applySnapshot(entry) {
    const { session, actor, snapshot } = entry;
    if (!actor || !snapshot) return;
    clearTvtEventBuffs(entry);

    if (entry.isBot && session) {
        delete session.tvtMatchId;
        delete session.tvtTeam;
        delete session.tvtSlotIndex;
        session.tvtLocked = false;
        session.plan = snapshot.plan || 'hunting';
        session.currentSpot = snapshot.currentSpot;
        session.spotRelocation = snapshot.spotRelocation;
        session.populationLocationPolicy = snapshot.populationLocationPolicy;
    }

    const restoreZ = Math.round(GeodataEngine.getHeight(snapshot.locX, snapshot.locY, snapshot.locZ));
    actor.state?.setDead?.(false);
    actor.state?.setSeated?.(false);
    if (typeof actor.setTitle === 'function') {
        actor.setTitle(snapshot.title ?? '');
    }
    if (typeof actor.setKarma === 'function') {
        actor.setKarma(Number(snapshot.karma || 0));
    }
    if (typeof actor.setPvpFlag === 'function') {
        actor.setPvpFlag(0);
    }
    if (session?.pvpFlagTimer) {
        clearTimeout(session.pvpFlagTimer);
        session.pvpFlagTimer = undefined;
    }
    if (session) {
        session.pvpFlagUntil = 0;
    }
    teleportToCoord(session, actor, {
        locX: snapshot.locX,
        locY: snapshot.locY,
        locZ: restoreZ
    });
    actor.fillupVitals?.();
    actor.statusUpdateVitals?.(actor);
    if (session && typeof session.dataSendToMe === 'function' && typeof ServerResponse?.userInfo === 'function') {
        session.dataSendToMe(ServerResponse.userInfo(actor));
    }
    if (session && typeof session.dataSendToOthers === 'function') {
        if (typeof ServerResponse?.charInfo === 'function') {
            session.dataSendToOthers(ServerResponse.charInfo(actor), actor);
        }
        if (typeof ServerResponse?.relationChanged === 'function') {
            session.dataSendToOthers(ServerResponse.relationChanged(actor), actor);
        }
    }
}

function resolveWinnerLabel(redKills, blueKills) {
    const r = Number(redKills || 0);
    const b = Number(blueKills || 0);
    if (r > b) return `Time RED venceu (${r} x ${b})`;
    if (b > r) return `Time BLUE venceu (${b} x ${r})`;
    return `Empate (${r} x ${b})`;
}

function startCountdownLoop(match, anchorActor) {
    clearMatchTimer();
    const announcedMarks = new Set();

    matchTickInterval = setInterval(() => {
        if (!activeMatch || activeMatch.id !== match.id) {
            clearMatchTimer();
            return;
        }

        enforceActiveMatchFlags(match);
        const now = Date.now();
        const remainingMs = Math.max(0, match.endsAt - now);
        const remainingSec = Math.ceil(remainingMs / 1000);
        const elapsedSec = Math.floor((now - match.startedAt) / 1000);

        if (remainingSec <= 0) {
            ColiseumTvtService.stopMatch('time_expired', anchorActor);
            return;
        }

        // A cada 1 minuto passado, anuncia quanto tempo falta para terminar
        const elapsedMinutes = Math.floor(elapsedSec / 60);
        if (elapsedMinutes >= 1 && remainingSec > 60) {
            const minuteKey = `min_${elapsedMinutes}`;
            if (!announcedMarks.has(minuteKey)) {
                announcedMarks.add(minuteKey);
                broadcastGlobalShout(
                    `[Coliseum TvT] Tempo decorrido: ${elapsedMinutes} ${elapsedMinutes === 1 ? 'minuto' : 'minutos'} — faltam ${formatRemainingHuman(remainingSec)} para o fim.`,
                    anchorActor
                );
            }
        }

        // No ultimo minuto: 30s, 15s, 10s e contagem regressiva nos ultimos 5s
        if (remainingSec <= 60) {
            if (remainingSec <= 5) {
                const secKey = `sec_${remainingSec}`;
                if (!announcedMarks.has(secKey)) {
                    announcedMarks.add(secKey);
                    broadcastGlobalShout(`[Coliseum TvT] Encerrando em ${remainingSec}...`, anchorActor);
                }
            } else {
                for (const mark of [30, 15, 10]) {
                    if (remainingSec <= mark && remainingSec > mark - 2) {
                        const markKey = `alert_${mark}`;
                        if (!announcedMarks.has(markKey)) {
                            announcedMarks.add(markKey);
                            broadcastGlobalShout(`[Coliseum TvT] Faltam ${mark} segundos para o fim da partida!`, anchorActor);
                        }
                    }
                }
            }
        }
    }, 250);
}

let lastMatchReport = null;

const ColiseumTvtService = {
    ARENA_CENTER,
    BOUNDS,
    TEAM_BASES,

    getActiveMatch() {
        return activeMatch;
    },

    isInsideArena(locX, locY, locZ) {
        const x = Number(locX);
        const y = Number(locY);
        const z = Number(locZ);
        return Number.isFinite(x) && Number.isFinite(y) && Number.isFinite(z)
            && x >= BOUNDS.minX && x <= BOUNDS.maxX
            && y >= BOUNDS.minY && y <= BOUNDS.maxY
            && z >= BOUNDS.minZ && z <= BOUNDS.maxZ;
    },

    clampToArena(locX, locY, locZ = ARENA_CENTER.locZ) {
        const margin = 150;
        const rawX = Number(locX);
        const rawY = Number(locY);
        const rawZ = Number(locZ);
        const x = Math.max(BOUNDS.minX + margin, Math.min(BOUNDS.maxX - margin, Number.isFinite(rawX) ? rawX : ARENA_CENTER.locX));
        const y = Math.max(BOUNDS.minY + margin, Math.min(BOUNDS.maxY - margin, Number.isFinite(rawY) ? rawY : ARENA_CENTER.locY));
        const z = Number.isFinite(rawZ) ? Math.max(BOUNDS.minZ + 50, Math.min(BOUNDS.maxZ - 50, rawZ)) : ARENA_CENTER.locZ;
        return {
            locX: Math.round(x),
            locY: Math.round(y),
            locZ: Math.round(GeodataEngine.getHeight(x, y, z))
        };
    },

    getTeamOfActor(actor) {
        const id = actorIdOf(actor);
        if (!activeMatch || !id) return null;
        return activeMatch.participantsByActorId.get(id)?.team || null;
    },

    isTvTParticipant(actor) {
        if (!activeMatch || !actor) return false;
        if (actor.session?.tvtMatchId && actor.session.tvtMatchId === activeMatch.id) return true;
        const id = actorIdOf(actor);
        return Boolean(id && activeMatch.participantsByActorId.has(id));
    },

    areEnemies(actorA, actorB) {
        const teamA = this.getTeamOfActor(actorA);
        const teamB = this.getTeamOfActor(actorB);
        return Boolean(teamA && teamB && teamA !== teamB);
    },

    isTvTCombatPair(attacker, victim) {
        if (!activeMatch || !attacker || !victim || attacker === victim) return false;
        if (this.areEnemies(attacker, victim)) return true;
        return this.isTvTParticipant(attacker) || this.isTvTParticipant(victim);
    },

    getCounterLabel(match = activeMatch) {
        if (!match) {
            return `0/${DEFAULT_TEAM_SIZE} vs 0/${DEFAULT_TEAM_SIZE}`;
        }
        const redCount = match.teams.RED.length;
        const blueCount = match.teams.BLUE.length;
        return `${redCount}/${match.targetPerTeam} vs ${blueCount}/${match.targetPerTeam}`;
    },

    getStatusSummary() {
        if (!activeMatch) {
            return {
                active: false,
                targetPerTeam: DEFAULT_TEAM_SIZE,
                counter: this.getCounterLabel(null),
                redCount: 0,
                blueCount: 0,
                redKills: 0,
                blueKills: 0,
                durationLabel: formatClock(DEFAULT_DURATION_MS),
                elapsedLabel: '00:00',
                remainingLabel: '00:00'
            };
        }
        const now = Date.now();
        const elapsedMs = Math.max(0, now - activeMatch.startedAt);
        const remainingMs = Math.max(0, activeMatch.endsAt - now);
        return {
            active: true,
            matchId: activeMatch.id,
            targetPerTeam: activeMatch.targetPerTeam,
            counter: this.getCounterLabel(activeMatch),
            redCount: activeMatch.teams.RED.length,
            blueCount: activeMatch.teams.BLUE.length,
            redKills: activeMatch.kills.RED,
            blueKills: activeMatch.kills.BLUE,
            durationLabel: formatClock(activeMatch.durationMs),
            elapsedLabel: formatClock(elapsedMs),
            remainingLabel: formatClock(remainingMs)
        };
    },

    startMatch(playerSession = null, options = {}) {
        if (activeMatch) {
            this.stopMatch('restarted', playerSession?.actor || null);
        }

        const requestedSize = Number(options.teamSize);
        const targetPerTeam = Number.isFinite(requestedSize) && requestedSize > 0
            ? Math.max(1, Math.min(MAX_PER_TEAM, Math.floor(requestedSize)))
            : DEFAULT_TEAM_SIZE;

        const requestedMinutes = Number(options.durationMinutes);
        const requestedDurationMs = Number(options.durationMs);
        const durationMs = Number.isFinite(requestedDurationMs) && requestedDurationMs >= 10000
            ? Math.floor(requestedDurationMs)
            : (Number.isFinite(requestedMinutes) && requestedMinutes > 0
                ? Math.max(10000, Math.floor(requestedMinutes * 60 * 1000))
                : DEFAULT_DURATION_MS);

        const playerTeam = options.playerTeam === 'BLUE' ? 'BLUE' : 'RED';
        const BotManager = invoke('GameServer/Bot/BotManager');

        matchCounter += 1;
        const startedAt = Date.now();
        const match = {
            id: `coliseum_tvt_${matchCounter}_${startedAt}`,
            startedAt,
            durationMs,
            endsAt: startedAt + durationMs,
            targetPerTeam,
            teams: { RED: [], BLUE: [] },
            kills: { RED: 0, BLUE: 0 },
            participantsByActorId: new Map()
        };

        const addEntry = (team, session, actor, isBot) => {
            const id = actorIdOf(actor);
            if (!actor || !id || match.participantsByActorId.has(id)) return false;
            if (match.teams[team].length >= targetPerTeam) return false;

            const slotIndex = match.teams[team].length;
            const coord = computeSlotCoord(team, slotIndex);
            const entry = {
                id,
                name: actorNameOf(actor),
                team,
                slotIndex,
                isBot,
                session,
                actor,
                initialCoord: { ...coord },
                snapshot: snapshotSession(session, isBot),
                kills: 0,
                deaths: 0
            };

            if (isBot && session) {
                session.tvtMatchId = match.id;
                session.tvtTeam = team;
                session.tvtSlotIndex = slotIndex;
                session.tvtLocked = true;
                session.spotRelocation = null;
            }

            match.teams[team].push(entry);
            match.participantsByActorId.set(id, entry);
            prepareCombatantActor(session, actor, coord, team);
            teleportToCoord(session, actor, coord);
            applyTeamTitleAndNoPk(session, actor, team);
            applyTvtEventBuffs(session, actor, entry);
            return true;
        };

        const playerActor = playerSession?.actor;
        if (playerActor && !isActorDead(playerActor)) {
            addEntry(playerTeam, playerSession, playerActor, false);
        }

        const eligibleBotSessions = (BotManager?.sessions || []).filter((sess) => {
            const actor = sess?.actor;
            if (!actor) return false;
            if (isMerchantSession(sess)) return false;
            if (sess.tvtLocked || sess.tvtMatchId) return false;
            return true;
        });

        for (const sess of eligibleBotSessions) {
            const redCount = match.teams.RED.length;
            const blueCount = match.teams.BLUE.length;
            if (redCount >= targetPerTeam && blueCount >= targetPerTeam) break;

            const nextTeam = redCount <= blueCount ? 'RED' : 'BLUE';
            addEntry(nextTeam, sess, sess.actor, true);
        }

        activeMatch = match;
        const anchorActor = playerActor || match.teams.RED[0]?.actor || match.teams.BLUE[0]?.actor || null;
        startCountdownLoop(match, anchorActor);
        broadcastGlobalShout(
            `[Coliseum TvT] Iniciado (${this.getCounterLabel(match)}) — Duracao: ${formatClock(durationMs)}.`,
            anchorActor
        );
        return this.getStatusSummary();
    },

    findEnemyTarget(session, bot, maxRange = 2800) {
        if (!activeMatch || !bot) return null;
        const myTeam = this.getTeamOfActor(bot);
        if (!myTeam) return null;

        const bx = Number(bot.fetchLocX?.() || 0);
        const by = Number(bot.fetchLocY?.() || 0);
        let bestTarget = null;
        let bestDistSq = maxRange * maxRange;

        for (const entry of activeMatch.participantsByActorId.values()) {
            if (entry.team === myTeam) continue;
            const candidate = entry.actor;
            if (!candidate || isActorDead(candidate)) continue;

            const cx = Number(candidate.fetchLocX?.() || 0);
            const cy = Number(candidate.fetchLocY?.() || 0);
            if (!this.isInsideArena(cx, cy, Number(candidate.fetchLocZ?.() || ARENA_CENTER.locZ))) continue;

            const dx = cx - bx;
            const dy = cy - by;
            const distSq = (dx * dx) + (dy * dy);
            if (distSq < bestDistSq) {
                bestDistSq = distSq;
                bestTarget = candidate;
            }
        }

        return bestTarget;
    },

    recordKill(victimActor, killerActor = null) {
        if (!activeMatch || !victimActor) return;
        const victimId = actorIdOf(victimActor);
        const victimEntry = activeMatch.participantsByActorId.get(victimId);
        if (!victimEntry) return;

        victimEntry.deaths = (victimEntry.deaths || 0) + 1;

        const killerId = actorIdOf(killerActor);
        const killerEntry = killerId ? activeMatch.participantsByActorId.get(killerId) : null;
        if (killerEntry && killerEntry.team !== victimEntry.team) {
            killerEntry.kills = (killerEntry.kills || 0) + 1;
            activeMatch.kills[killerEntry.team] = (activeMatch.kills[killerEntry.team] || 0) + 1;
        } else {
            const winningSide = victimEntry.team === 'RED' ? 'BLUE' : 'RED';
            activeMatch.kills[winningSide] = (activeMatch.kills[winningSide] || 0) + 1;
        }
    },

    buildScoreboard(match) {
        if (!match?.participantsByActorId) return [];
        return Array.from(match.participantsByActorId.values())
            .map((entry) => ({
                id: entry.id,
                name: entry.name,
                team: entry.team,
                isBot: Boolean(entry.isBot),
                kills: Number(entry.kills || 0),
                deaths: Number(entry.deaths || 0)
            }))
            .sort((a, b) => {
                if (b.kills !== a.kills) return b.kills - a.kills;
                if (a.deaths !== b.deaths) return a.deaths - b.deaths;
                return String(a.name || '').localeCompare(String(b.name || ''));
            });
    },

    getLastMatchReport() {
        return lastMatchReport || null;
    },

    getRespawnCoord(actor) {
        if (!activeMatch || !actor) return null;
        const id = actorIdOf(actor);
        const entry = activeMatch.participantsByActorId.get(id);
        if (!entry) return null;
        if (entry.initialCoord) {
            return { ...entry.initialCoord };
        }
        return computeSlotCoord(entry.team, entry.slotIndex);
    },

    handleActorRespawn(session, actor) {
        if (!activeMatch || !actor) return false;
        const id = actorIdOf(actor);
        const entry = activeMatch.participantsByActorId.get(id);
        if (!entry) return false;
        const coord = this.getRespawnCoord(actor);
        if (!coord) return false;
        prepareCombatantActor(session, actor, coord, entry.team);
        teleportToCoord(session, actor, coord);
        applyTeamTitleAndNoPk(session, actor, entry.team);
        applyTvtEventBuffs(session, actor, entry);
        return true;
    },

    stopMatch(reason = 'finished', anchorActor = null) {
        clearMatchTimer();
        if (!activeMatch) return this.getStatusSummary();
        const finishedMatch = activeMatch;
        activeMatch = null;

        const winnerLabel = resolveWinnerLabel(finishedMatch.kills.RED, finishedMatch.kills.BLUE);
        const speaker = anchorActor || finishedMatch.teams.RED[0]?.actor || finishedMatch.teams.BLUE[0]?.actor || null;

        for (const entry of finishedMatch.participantsByActorId.values()) {
            applySnapshot(entry);
        }

        broadcastGlobalShout(
            `[Coliseum TvT] Encerrado! ${winnerLabel} | Placar final RED ${finishedMatch.kills.RED} x ${finishedMatch.kills.BLUE} BLUE.`,
            speaker
        );

        const scoreboard = this.buildScoreboard(finishedMatch);
        const report = {
            active: false,
            reason,
            winner: winnerLabel,
            counter: this.getCounterLabel(finishedMatch),
            redKills: finishedMatch.kills.RED,
            blueKills: finishedMatch.kills.BLUE,
            durationLabel: formatClock(finishedMatch.durationMs),
            elapsedLabel: formatClock(Math.max(0, Date.now() - finishedMatch.startedAt)),
            remainingLabel: '00:00',
            totalParticipants: scoreboard.length,
            scoreboard
        };
        lastMatchReport = report;
        return report;
    }
};

module.exports = ColiseumTvtService;
